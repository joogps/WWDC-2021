// This SwiftUI view presents the main and final screen of the playground experience

import SwiftUI

struct CanvasScreen: View {
    @EnvironmentObject var playgroundData: DataModel
    
    var animation: Namespace.ID
    
    @GestureState var offset: CGSize = .zero
    @GestureState var scale: CGFloat = 1.0
    
    var body: some View {
        ZStack {
            Color.playgroundTheme.white
            
            ZStack {
                background
                
                ZStack {
                    ForEach(playgroundData.mathSets, id: \.name) { set in
                       MathSetView(set: set)
                    }
                }.frame(width: playgroundSize.width, height: playgroundSize.height)
            }.offset(offset)
            .scaleEffect(scale)
            .animation(.easeInOut)
            
            HUDView(animation: animation)
        }.gesture(DragGesture().updating($offset) { value, state, transaction in
            let width = value.translation.width
            let height = value.translation.height
            state = CGSize(width: width/pow(2, abs(width)/500+1), height: height/pow(2, abs(height)/500+1))
        }).gesture(MagnificationGesture().updating($scale) { value, state, transaction in
            let normalized = abs(value+1)
            state = max(min(normalized/pow(2, normalized/500+1), 2), 0.5)
        })
    }
    
    var background: some View {
        Image(nsImage: NSImage(named: "Background Tile.png")!)
            .resizable(resizingMode: .tile)
            .opacity(0.1)
            .frame(width: playgroundSize.width*2, height: playgroundSize.height*2)
    }
}

struct MathSetView: View {
    @EnvironmentObject var playgroundData: DataModel
    
    let set: MathSet
    
    @State var showingPopover = false
    
    var body: some View {
        Circle()
            .stroke(set.color,lineWidth: 4)
            .background(Circle().foregroundColor(set.color.opacity(0.4)))
            .popover(isPresented: $showingPopover) {
                if set.intersections.count == 0 {
                    MathSetPopoverView(set: set)
                        .padding(20)
                } else {
                    VStack {
                        Text("Intersection").font(.system(size: 16, weight: .bold))
                        Divider()
                        HStack {
                            ForEach(set.intersections, id: \.name) { set in
                                MathSetPopoverView(set: set)
                            }
                        }
                    }.padding(20)
                }
            }.frame(width: set.size, height: set.size)
            .position(set.position)
            .blendMode(.multiply)
            .onTapGesture {
                showingPopover = true
                playgroundData.showedPopover.toggle()
            }
    }
}

struct MathSetPopoverView: View {
    let set: MathSet
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Set ").font(.system(size: 15)) + Text(set.name).font(.system(size: 15, weight: .regular, design: .serif))
            Text(set.items.count > 0 ? "\(set.items.count) items" : "Empty set")
                .font(.system(size: 13))
                .foregroundColor(Color(.systemGray))
            Divider()
            Text(set.parsedItems).font(.system(size: 12, weight: .regular, design: .serif))
        }
    }
}
