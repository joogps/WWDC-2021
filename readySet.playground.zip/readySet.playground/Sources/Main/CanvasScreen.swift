// This SwiftUI view presents the main and final screen of the playground experience

import SwiftUI

struct CanvasScreen: View {
    @EnvironmentObject var playgroundData: DataModel
    
    var animation: Namespace.ID
    
    @GestureState var offset: CGSize = .zero
    @GestureState var scale: CGFloat = 1.0
    
    var body: some View {
        ZStack {
            Color.playgroundTheme.white
            
            ZStack {
                background
                
                HStack {
                    Spacer()
                    ForEach(playgroundData.parsedObjects, id: \.id) { object in
                        MathObjectView(object: object, animation: animation)
                        Spacer()
                    }
                }.frame(width: playgroundSize.width, height: playgroundSize.height)
            }.offset(offset)
            .scaleEffect(scale)
            .animation(.easeInOut)
            
            HUDView(animation: animation)
        }.gesture(DragGesture().updating($offset) { value, state, transaction in
            let width = value.translation.width
            let height = value.translation.height
            state = CGSize(width: width/pow(2, abs(width)/500+1), height: height/pow(2, abs(height)/500+1))
        }).gesture(MagnificationGesture().updating($scale) { value, state, transaction in
            let normalized = abs(value+1)
            state = max(min(normalized/pow(2, normalized/500+1), 2), 0.5)
        })
    }
    
    var background: some View {
        Image(nsImage: NSImage(named: "Background Tile.png")!)
            .resizable(resizingMode: .tile)
            .opacity(0.1)
            .frame(width: playgroundSize.width*2, height: playgroundSize.height*2)
    }
}

struct MathObjectView: View {
    var object: MathObject
    
    var animation: Namespace.ID
    
    @ViewBuilder
    var body: some View {
        if type(of: object) == MathSet.self {
            MathSetView(set: object as! MathSet, animation: animation)
        } else if type(of: object) == MathIntersection.self {
            MathIntersectionView(intersection: object as! MathIntersection, animation: animation)
        } else if type(of: object) == MathContainment.self {
            MathContainmentView(containment: object as! MathContainment, animation: animation)
        } else if type(of: object) == MathThreeway.self {
            MathThreewayView(threeway: object as! MathThreeway, animation: animation)
        }
    }
}

struct MathSetView: View {
    @EnvironmentObject var playgroundData: DataModel
    
    let set: MathSet
    
    var animation: Namespace.ID
    
    @State var showingPopover = false
    
    var item: UserMathSet {
        return set.item
    }
    
    var body: some View {
        Circle()
            .stroke(item.color,lineWidth: 4)
            .background(Circle().foregroundColor(item.color.opacity(0.4)))
            .popover(isPresented: $showingPopover) {
                /*if item.intersections.count == 0 {
                    MathSetPopoverView(set: set)
                        .padding(20)
                } else {
                    VStack {
                        Text("Intersection").font(.system(size: 16, weight: .bold))
                        Divider()
                        HStack {
                            ForEach(set.intersections, id: \.name) { set in
                                MathSetPopoverView(set: set)
                            }
                        }
                    }.padding(20)
                }*/
            }.frame(width: set.size, height: set.size)
            .blendMode(.multiply)
            .onTapGesture {
                showingPopover = true
                playgroundData.showedPopover.toggle()
            }
            .matchedGeometryEffect(id: set.item.name, in: animation)
    }
}

struct MathIntersectionView: View {
    let intersection: MathIntersection
    
    var animation: Namespace.ID
    
    var body: some View {
        HStack(spacing: -intersection.gap) {
            MathObjectView(object: intersection.lhs, animation: animation)
            MathObjectView(object: intersection.rhs, animation: animation)
        }
    }
}

struct MathContainmentView: View {
    let containment: MathContainment
    
    var animation: Namespace.ID
    
    var body: some View {
        ZStack {
            MathObjectView(object: containment.outer, animation: animation)
            MathObjectView(object: containment.inner, animation: animation)
        }
    }
}

struct MathThreewayView: View {
    let threeway: MathThreeway
    
    var animation: Namespace.ID
    
    var body: some View {
        ZStack {
            MathObjectView(object: threeway.top, animation: animation)
                .offset(x: 0, y: -threeway.offset.top)
            MathObjectView(object: threeway.lhs, animation: animation)
                .offset(x: cos(135.0 * CGFloat.pi / 180.0)*threeway.offset.lhs, y: sin(135.0 * CGFloat.pi / 180.0)*threeway.offset.lhs)
            MathObjectView(object: threeway.rhs, animation: animation)
                .offset(x: cos(45.0 * CGFloat.pi / 180.0)*threeway.offset.rhs, y: sin(45.0 * CGFloat.pi / 180.0)*threeway.offset.rhs)
        }
    }
}


/*struct MathSetView: View {
    @EnvironmentObject var playgroundData: DataModel
    
    let set: UserMathSet
    
    @State var showingPopover = false
    
    var body: some View {
        Circle()
            .stroke(set.color,lineWidth: 4)
            .background(Circle().foregroundColor(set.color.opacity(0.4)))
            .popover(isPresented: $showingPopover) {
                if set.intersections.count == 0 {
                    MathSetPopoverView(set: set)
                        .padding(20)
                } else {
                    VStack {
                        Text("Intersection").font(.system(size: 16, weight: .bold))
                        Divider()
                        HStack {
                            ForEach(set.intersections, id: \.name) { set in
                                MathSetPopoverView(set: set)
                            }
                        }
                    }.padding(20)
                }
            }.frame(width: set.size, height: set.size)
            .position(set.position)
            .blendMode(.multiply)
            .onTapGesture {
                showingPopover = true
                playgroundData.showedPopover.toggle()
            }
    }
}
 */

struct MathSetPopoverView: View {
    let set: UserMathSet
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Set ").font(.system(size: 15)) + Text(set.name).font(.system(size: 15, weight: .regular, design: .serif))
            Text(set.elements.count > 0 ? "\(set.elements.count) items" : "Empty set")
                .font(.system(size: 13))
                .foregroundColor(Color(.systemGray))
            Divider()
            Text(set.parsedItems).font(.system(size: 12, weight: .regular, design: .serif))
        }
    }
}
