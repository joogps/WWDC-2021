import SwiftUI

struct HUDView: View {
    @EnvironmentObject var playgroundData: DataModel
    
    var animation: Namespace.ID
    
    @State var messageCondition: (() -> (HUDPhases?))?
    
    @State var text: String = ""
    @State var definingBy: Definitions = .enumeration
    
    let setStyles = [(name: "A", color: Color.playgroundTheme.blue),
                     (name: "B", color: Color.playgroundTheme.green),
                     (name: "C", color: Color.playgroundTheme.yellow)]
    var currentSetStyle: (name: String, color: Color) {
        playgroundData.currentSets.count < setStyles.count ? setStyles[playgroundData.currentSets.count] : (name: "A", color: Color.playgroundTheme.blue)
    }
    
    @State var currentMenu: HUDMenus?
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            VStack(alignment: .trailing) {
                Spacer()
                messages
                toolbar
            }
            
            HStack(alignment: .top) {
                switch currentMenu {
                case .selection:
                    selectionMenu
                case .empty:
                    emptyMenu
                default:
                    menus
                }
                Spacer()
                
                counter
            }
        }.padding(30)
        .shadow(color: Color.black.opacity(0.05), radius: 10, x: 5, y: 5)
        .frame(width: playgroundSize.width, height: playgroundSize.height)
        .onChange(of: playgroundData.popoversShown) { _ in
            evaluateCondition()
        }.onChange(of: playgroundData.userSetFiles) { _ in
            evaluateCondition()
        }.onChange(of: text) { _ in
            evaluateCondition()
        }
    }
    
    func evaluateCondition() {
        if messageCondition != nil {
            if let result = messageCondition!() {
                playgroundData.currentCanvasPhase = result
            }
        }
    }
    
    @ViewBuilder
    var messages: some View {
        switch playgroundData.currentCanvasPhase {
        case .welcome:
            HUDMessageView(text: "Welcome to the 􀮋 Canvas./ Here is where you will interact with sets. ", nextPhase: .tryit, animation: animation)
        case .tryit:
            HUDMessageView(text: "There's a nice lil' toolbar right below me./ You can use it to create your first set!/\n\nJust 􀇳 type the numbers you want to add to it, separated by commas. ", onAppear: {
                    messageCondition = { text.count > 6 ? .send : nil }
                })
        case .send:
            HUDMessageView(text: "Now hit 􀁧 to send your set to the.../ set manager. ", onAppear: {
                messageCondition = {
                    if playgroundData.currentSets.count > 0 {
                        if playgroundData.currentSets[0].elements.count == 0 {
                            DispatchQueue.main.asyncAfter(deadline: .now()+8, execute: { playgroundData.currentCanvasPhase = .empty })
                        } else {
                            DispatchQueue.main.asyncAfter(deadline: .now()+8, execute: { playgroundData.currentCanvasPhase = .click })
                        }
                        return .great
                    } else {
                        return nil
                    }
                }
            })
        case .great:
            HUDMessageView(text: "Great!/ See your shiny new set being drawn there?/ That type of drawing is known as a Venn diagram.", nextPhase: .click)
        case .empty:
            HUDMessageView(text: "The set you have created is actually an empty set! But, don't worry, you'd get to that part eventually. Oh, by the way, empty sets can be also represented with the symbol Ø.")
        case .click:
            HUDMessageView(text: "Now try to click on it to view more information.", onAppear: {
                messageCondition = { playgroundData.popoversShown > 0 ? .newset : nil }
            })
        case .newset:
            HUDMessageView(text: "Awesome! 🎉/\n\nNow go ahead and create a new set, containing only some of the items of this already existing set, to see what happens. ")
        }
    }
    
    var toolbar: some View {
        VStack(spacing: 0) {
            sets.frame(maxHeight: playgroundData.currentSets.count > 0 ? 10 : 0)
            
            HStack(spacing: 0) {
                notation
                input
            }.frame(height: 50)
        }.cornerRadius(15.0)
    }
    
    var sets: some View {
        HStack(alignment: .bottom, spacing: 0) {
            ForEach(playgroundData.currentSets, id: \.name) { set in
                set.color
            }
        }.overlay(LinearGradient(gradient: Gradient(colors: [Color.white.opacity(0.3), Color.white.opacity(0)]), startPoint: .top, endPoint: .center))
    }
    
    var notation: some View {
        ZStack {
            Color.white
            
            Menu {
                Text("Notation")
                
                Button(action: {
                    definingBy = .enumeration
                }) {
                    Text("Enumeration \(definingBy == .enumeration ? "􀆅" : "")")
                }
                Button(action: {
                    definingBy = .builder
                }) {
                    Text("Set-builder \(definingBy == .builder ? "􀆅" : "")")
                }.hidden()
            } label: {
                EmptyView()
                    .frame(width: 50, height: 50)
            }.menuStyle(BorderlessButtonMenuStyle())
            .opacity(0.1)
            
            Image(systemName: definingBy == .enumeration ? "number" : "rectangle.portrait.arrowtriangle.2.inward")
                .allowsHitTesting(false)
                .font(.system(size: 22, weight: .medium))
        }.aspectRatio(1.0, contentMode: .fit)
    }
    
    var input: some View {
        HStack(spacing: 0) {
            ZStack {
                Color(hue: Double(NSColor(currentSetStyle.color).hueComponent), saturation: 0.03, brightness: 1.0)
                
                HStack {
                    Text("\(currentSetStyle.name) = {")
                        .foregroundColor(Color(hue: Double(NSColor(currentSetStyle.color).hueComponent), saturation: 0.5, brightness: 0.4))
                        .font(.system(size: 20, weight: .regular, design: .serif))
                    
                    ZStack(alignment: .leading) {
                        TextField("2, 3, 5...", text: $text)
                            .textFieldStyle(PlainTextFieldStyle())
                        
                        (Text(text != "" ? text : "2, 3, 5...").foregroundColor(.clear) +
                        Text(" }")
                        .font(.system(size: 20, weight: .regular, design: .serif))
                        .foregroundColor(Color(hue: Double(NSColor(currentSetStyle.color).hueComponent), saturation: 0.5, brightness: 0.4))).lineLimit(1).allowsHitTesting(false)
                    }.font(Font(getFontWithAlignedNumbers(font: "Raleway", size: 20)))
                }.padding(.horizontal, 15)
            }
            
            ZStack {
                Color.white
                
                Button("", action: addSet).opacity(0)
                .allowsHitTesting(false)
                    .keyboardShortcut(.return, modifiers: [])
                
                Button(action: addSet) {
                    Image(systemName: "arrowtriangle.up.circle.fill")
                        .font(.system(size: 25))
                        .foregroundColor(currentSetStyle.color)
                }.buttonStyle(PlainButtonStyle())
            }.aspectRatio(1.0, contentMode: .fit)
        }.disabled(playgroundData.currentSets.count >= setStyles.count)
    }
    
    func addSet() {
        let elements = Set(text.components(separatedBy: ",").compactMap { Float($0.trimmingCharacters(in: .whitespaces)) })
        
        withAnimation {
            playgroundData.currentSets.append(UserMathSet(name: currentSetStyle.name, color: currentSetStyle.color, elements: elements))
            playgroundData.parseSets()
        }
        
        text = ""
    }
    
    var menus: some View {
        VStack {
            Button(action: {
                withAnimation(.spring(response: 0.35, dampingFraction: 0.65)) {
                    currentMenu = .selection
                }
            }) {
                HUDButton(systemName: "folder.fill", animation: animation)
            }.buttonStyle(PlainButtonStyle())
            
            Button(action: {
                withAnimation(.spring(response: 0.35, dampingFraction: 0.65)) {
                    currentMenu = .empty
                }
            }) {
                HUDButton(systemName: "trash.fill", animation: animation)
            }.buttonStyle(PlainButtonStyle())
        }
    }
    
    var emptyMenu: some View {
        ZStack(alignment: .topLeading) {
            HUDMenuBackground(cornerRadius: 25.0)
                .matchedGeometryEffect(id: "Background-trash.fill", in: animation)
            
            VStack(alignment: .leading) {
                HUDMenuHeader(title: "Empty canvas", systemName: "trash.fill", animation: animation)
                    .font(Font.custom("Raleway", size: 20).weight(.bold))
                    .frame(height: 18)
                Spacer()
                
                Text("Are you sure you want to empty the canvas? You'll lose all your precious sets forever.")
                    .font(Font.custom("Raleway", size: 13).weight(.medium))
                
                Spacer()
                HStack {
                    Button(action: dismissMenu, label: {
                        HUDCapsuleButton(label: "Cancel")
                    }).buttonStyle(PlainButtonStyle())
                    
                    Button(action: {
                        withAnimation {
                            playgroundData.currentSets = []
                            playgroundData.parsedObjects = []
                        }
                            
                        dismissMenu()
                    }, label: {
                        HUDCapsuleButton(label: "Yes", destructive: true)
                    }).buttonStyle(PlainButtonStyle())
                }.frame(height: 35)
                .font(Font.custom("Raleway", size: 16).weight(.semibold))
            }.foregroundColor(Color.playgroundTheme.black)
            .padding(20)
        }.frame(width: 275, height: 165)
        .onTapGesture(perform: dismissMenu)
    }
    
    var selectionMenu: some View {
        ZStack(alignment: .topLeading) {
            HUDMenuBackground(cornerRadius: 25.0)
                .matchedGeometryEffect(id: "Background-folder.fill", in: animation)
            
            VStack(alignment: .leading, spacing: 5) {
                HUDMenuHeader(title: "File selection", systemName: "folder.fill", animation: animation)
                    .font(Font.custom("Raleway", size: 20).weight(.bold))
                    .frame(height: 18)
                Spacer()
                
                VStack(spacing: 5) {
                    ForEach(playgroundData.userSetFiles) { file in
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.1)) {
                                playgroundData.currentFileIndex = playgroundData.userSetFiles.firstIndex(of: file)!
                                playgroundData.parseSets()
                            }
                        }, label: {
                            HUDSelectionButton(file: file)
                        }).buttonStyle(PlainButtonStyle())
                    }
                }
            }.foregroundColor(Color.playgroundTheme.black)
            .padding(20)
        }.frame(width: 275, height: 285)
        .onTapGesture(perform: dismissMenu)
    }
    
    func dismissMenu() {
        withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
            currentMenu = nil
        }
    }
    
    var counter: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25.0).fill(Color.white)
            
            HStack(spacing: 0) {
                Image(nsImage: NSImage(named: "Set Bits.png")!)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                Spacer()
                
                HStack(spacing: 0) {
                    Spacer()
                    Text(String(playgroundData.currentSets.count))
                        .font(Font(getFontWithAlignedNumbers(font: "Raleway", size: 38)).weight(.bold))
                        .fixedSize()
                    Spacer()
                }
            }.padding(7)
            .foregroundColor(Color.playgroundTheme.black)
        }.frame(width: 110, height: 55)
        .animation(nil)
    }
}

struct HUDMessageView: View {
    @EnvironmentObject var playgroundData: DataModel
    
    var text: String
    
    var nextPhase: HUDPhases? = nil
    var delay: Double = 3.0
    var onAppear: () -> () = {}
    
    var animation: Namespace.ID?
    
    @State var showingSpeech = false
    @State var paused = false
    
    var body: some View {
        VStack(alignment: .trailing) {
            Spacer()
            
            if showingSpeech {
                speech
            }
            
            SethView(paused: $paused)
                .frame(width: 165)
                .animation(.easeInOut(duration: 1.25))
                .matchedGeometryEffect(id: "Seth", in: animation ?? Namespace().wrappedValue)
        }.onAppear {
            onAppear()
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                showingSpeech = true
            }
        }.onHover { over in
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                showingSpeech = !over
                paused = over
            }
        }
    }
    
    var speech: some View {
        SpeechView(text: text, completion: {
            paused = true
            DispatchQueue.main.asyncAfter(deadline: .now()+delay, execute: {
                if nextPhase != nil {
                    playgroundData.currentCanvasPhase = nextPhase!
                }
            })
        }, arrowPosition: .bottomTrailing, lineWidth: 10.0, innerPadding: 15)
            .foregroundColor(Color.playgroundTheme.black)
            .font(Font.custom("Raleway", size: 16).weight(.semibold))
            .frame(width: 215)
            .transition(AnyTransition.scale(scale: 0.5, anchor: .bottomTrailing).combined(with: .opacity))
    }
}

struct HUDButton: View {
    var systemName: String
    var animation: Namespace.ID?
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25.0).fill(Color.white)
                .matchedGeometryEffect(id: "Background-\(systemName)", in: animation ?? Namespace().wrappedValue)
            Image(systemName: systemName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .foregroundColor(Color.playgroundTheme.black)
                .matchedGeometryEffect(id: systemName, in: animation ?? Namespace().wrappedValue)
                .padding(14)
        }.frame(width: 50, height: 50)
    }
}

struct HUDMenuHeader: View {
    var title: String
    var systemName: String
    
    var animation: Namespace.ID?
    
    var body: some View {
        HStack {
            Image(systemName: systemName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .matchedGeometryEffect(id: systemName, in: animation ?? Namespace().wrappedValue)
            Text(title)
        }
    }
}

struct HUDCapsuleButton: View {
    var label: String = ""
    var destructive: Bool = false
    
    var body: some View {
        ZStack {
            Capsule().fill(destructive ? Color.playgroundTheme.orange : Color.playgroundTheme.white)
            Text(label).foregroundColor(destructive ? Color.white : Color.primary)
        }
    }
}

struct HUDSelectionButton: View {
    @EnvironmentObject var playgroundData: DataModel
    
    var file: UserFile
    
    var body: some View {
        ZStack {
            Capsule().fill(file == playgroundData.currentFile ? Color.playgroundTheme.blue : Color.playgroundTheme.white)
            
            HStack(spacing: 4) {
                Text(file.name)
                    .font(Font(getFontWithAlignedNumbers(font: "Raleway", size: 16)).weight(.medium))
                    .padding(.leading, 5)
                Spacer()
                
                if file.userSets.count > 0 {
                    Image(nsImage: NSImage(named: "Set Bits.png")!)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                    Text(String(file.userSets.count))
                        .font(Font(getFontWithAlignedNumbers(font: "Raleway", size: 14)).weight(.bold))
                } else {
                    Text("-")
                        .font(Font.custom("Raleway", size: 14).weight(.bold))
                }
                
                Spacer()
                Image(systemName: file == playgroundData.currentFile ? "checkmark.circle.fill" : "circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            }.padding(10)
        }.foregroundColor(file == playgroundData.currentFile ? Color.playgroundTheme.white : Color.playgroundTheme.black)
    }
}

struct HUDMenuBackground: View {
    var cornerRadius: CGFloat
    
    var body: some View {
        RoundedRectangle(cornerRadius: cornerRadius)
            .fill(Color.white)
    }
}

enum HUDMenus {
    case empty
    case selection
}

enum HUDPhases {
    case welcome
    case tryit
    case send
    case great
    case empty
    case click
    case newset
}
