import SwiftUI

struct HUDView: View {
    @EnvironmentObject var playgroundData: DataModel
    
    var animation: Namespace.ID
    
    @State var messageCondition: (() -> (CanvasPhases?))?
    
    @State var text: String = ""
    @State var definingBy: Definitions = .enumeration
    
    let setStyles = [(name: "A", color: Color.playgroundTheme.blue),
                     (name: "B", color: Color.playgroundTheme.green),
                     (name: "C", color: Color.playgroundTheme.yellow)]
    var currentSetStyle: (name: String, color: Color) {
        playgroundData.mathSets.count < setStyles.count ? setStyles[playgroundData.mathSets.count] : (name: "A", color: Color.playgroundTheme.blue)
    }
    
    @State var showingAlert = false
    
    var body: some View {
        VStack(alignment: .trailing) {
            HStack{
                Button(action: {
                    showingAlert = true
                }) {
                    ZStack {
                        Circle().fill(Color.white)
                        Image(systemName: "trash.fill")
                            .resizable()
                            .foregroundColor(Color.playgroundTheme.black)
                            .padding(14)
                    }.frame(width: 50, height: 50)
                }.buttonStyle(PlainButtonStyle())
                Spacer()
                Button(action: {}) {
                    ZStack {
                        Circle().fill(Color.white)
                        Image(systemName: "text.book.closed.fill")
                            .resizable()
                            .foregroundColor(Color.playgroundTheme.black)
                            .padding(14)
                    }.frame(width: 50, height: 50)
                }.buttonStyle(PlainButtonStyle())
            }
            
            Spacer()
            switch playgroundData.currentCanvasPhase {
            case .welcome:
                HUDMessageView(text: "Welcome to the 􀮋 Canvas./ Here is where you will interact with sets. ", nextPhase: .tryit, animation: animation)
            case .tryit:
                HUDMessageView(text: "There's a nice lil' toolbar right below me./ You can use it to create your first set!/\n\nJust 􀇳 type the numbers you want to add to it, separated by commas. ", onAppear: {
                        messageCondition = { text.count > 6 ? .send : nil }
                    })
            case .send:
                HUDMessageView(text: "Now hit 􀁧 to send your set to the.../ set manager. ", onAppear: {
                    messageCondition = {
                        if playgroundData.mathSets.count > 0 {
                            if playgroundData.mathSets[0].items.count == 0 {
                                DispatchQueue.main.asyncAfter(deadline: .now()+8, execute: { playgroundData.currentCanvasPhase = .empty })
                            } else {
                                DispatchQueue.main.asyncAfter(deadline: .now()+8, execute: { playgroundData.currentCanvasPhase = .click })
                            }
                            return .great
                        } else {
                            return nil
                        }
                    }
                })
            case .great:
                HUDMessageView(text: "Great!/ See your shiny new set being drawn there?/ That type of drawing is known as a Venn diagram.", nextPhase: .click)
            case .empty:
                HUDMessageView(text: "The set you have created is actually an empty set! But, don't worry, you'd get to that part eventually. Oh, by the way, empty sets can be also represented with the symbol Ø.")
            case .click:
                HUDMessageView(text: "Now try to click on it to view more information.", onAppear: {
                    messageCondition = { playgroundData.showedPopover ? .newset : nil }
                })
            case .newset:
                HUDMessageView(text: "Awesome! 🎉/\n\nNow go ahead and create a new set, containing only some of the items of this already existing set, to see what happens. ")
            }
            
            toolbar
        }.padding(30)
        .shadow(color: Color.black.opacity(0.05), radius: 10, x: 5, y: 5)
        .frame(width: playgroundSize.width, height: playgroundSize.height)
        .alert(isPresented: $showingAlert) {
            Alert(title: Text("Seth says").bold(), message: Text("Are you sure you want to empty the 􀮋 Canvas? This action is not reversible."), primaryButton: .destructive(Text("Yes")) {
                playgroundData.mathSets = []
            }, secondaryButton: .cancel())
        }.onChange(of: playgroundData.showedPopover) { _ in
            evaluateCondition()
        }.onChange(of: playgroundData.mathSets) { _ in
            evaluateCondition()
        }.onChange(of: text) { _ in
            evaluateCondition()
        }
    }
    
    func evaluateCondition() {
        if messageCondition != nil {
            if let result = messageCondition!() {
                playgroundData.currentCanvasPhase = result
            }
        }
    }
    
    var toolbar: some View {
        VStack(spacing: 0) {
            sets.frame(maxHeight: playgroundData.mathSets.count > 0 ? 10 : 0)
            
            HStack(spacing: 0) {
                menu
                input
            }.frame(height: 50)
        }.cornerRadius(15.0)
    }
    
    var sets: some View {
        HStack(alignment: .bottom, spacing: 0) {
            ForEach(playgroundData.mathSets, id: \.name) { set in
                set.color
            }
        }.overlay(LinearGradient(gradient: Gradient(colors: [Color.white.opacity(0.3), Color.white.opacity(0)]), startPoint: .top, endPoint: .center))
    }
    
    var menu: some View {
        ZStack {
            Color.white
            
            Menu {
                Text("Notation")
                
                Button(action: {
                    definingBy = .enumeration
                }) {
                    Text("Enumeration \(definingBy == .enumeration ? "􀆅" : "")")
                }
                Button(action: {
                    definingBy = .builder
                }) {
                    Text("Set-builder \(definingBy == .builder ? "􀆅" : "")")
                }.disabled(true)
            } label: {
                EmptyView()
                    .frame(width: 50, height: 50)
            }.menuStyle(BorderlessButtonMenuStyle())
            .opacity(0.1)
            
            Image(systemName: definingBy == .enumeration ? "number" : "rectangle.portrait.arrowtriangle.2.inward")
                .allowsHitTesting(false)
                .font(.system(size: 22, weight: .medium))
        }.aspectRatio(1.0, contentMode: .fit)
    }
    
    var input: some View {
        HStack(spacing: 0) {
            ZStack {
                Color(hue: Double(NSColor(currentSetStyle.color).hueComponent), saturation: 0.03, brightness: 1.0)
                
                HStack {
                    Text("\(currentSetStyle.name) = {")
                        .foregroundColor(Color(hue: Double(NSColor(currentSetStyle.color).hueComponent), saturation: 0.5, brightness: 0.4))
                        .font(.system(size: 20, weight: .regular, design: .serif))
                    
                    ZStack(alignment: .leading) {
                        TextField("2, 3, 5...", text: $text)
                            .textFieldStyle(PlainTextFieldStyle())
                        
                        (Text(text != "" ? text : "2, 3, 5...").foregroundColor(.clear) +
                        Text(" }")
                        .font(.system(size: 20, weight: .regular, design: .serif))
                        .foregroundColor(Color(hue: Double(NSColor(currentSetStyle.color).hueComponent), saturation: 0.5, brightness: 0.4))).lineLimit(1).allowsHitTesting(false)
                    }.font(Font(getFontWithAlignedNumbers(font: "Raleway", size: 20)))
                }.padding(.horizontal, 15)
            }
            
            ZStack {
                Color.white
                
                Button("", action: addSet).opacity(0)
                .allowsHitTesting(false)
                    .keyboardShortcut(.return, modifiers: [])
                
                Button(action: addSet) {
                    Image(systemName: "arrowtriangle.up.circle.fill")
                        .font(.system(size: 25))
                        .foregroundColor(currentSetStyle.color)
                }.buttonStyle(PlainButtonStyle())
            }.aspectRatio(1.0, contentMode: .fit)
        }.disabled(playgroundData.mathSets.count >= setStyles.count)
    }
    
    func addSet() {
        let items = Set(text.components(separatedBy: ",").compactMap { Float($0.trimmingCharacters(in: .whitespaces)) })
        withAnimation {
            playgroundData.mathSets.append(MathSet(name: currentSetStyle.name, color: currentSetStyle.color, items: items))
        }
        playgroundData.parseSets()
        text = ""
    }
}

struct HUDMessageView: View {
    var text: String
    
    var nextPhase: CanvasPhases? = nil
    var delay: Double = 3.0
    var onAppear: () -> () = {}
    
    @EnvironmentObject var playgroundData: DataModel
    
    var animation: Namespace.ID?
    
    @State var showingSpeech = false
    @State var paused = false
    
    var body: some View {
        VStack(alignment: .trailing) {
            Spacer()
            
            if showingSpeech {
                speech
            }
            
            SethView(paused: $paused)
                .frame(width: 165)
                .animation(.easeInOut(duration: 1.25))
                .matchedGeometryEffect(id: "Seth", in: animation ?? Namespace().wrappedValue)
        }.onAppear {
            onAppear()
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                showingSpeech = true
            }
        }.onHover { over in
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                showingSpeech = !over
                paused = over
            }
        }
    }
    
    var speech: some View {
        SpeechView(text: text, completion: {
            paused = true
            DispatchQueue.main.asyncAfter(deadline: .now()+delay, execute: {
                if nextPhase != nil {
                    playgroundData.currentCanvasPhase = nextPhase!
                }
            })
        }, arrowPosition: .bottomTrailing, lineWidth: 10.0, innerPadding: 15)
            .foregroundColor(Color.playgroundTheme.black)
            .font(Font.custom("Raleway", size: 16).weight(.semibold))
            .frame(width: 215)
            .transition(AnyTransition.scale(scale: 0.5, anchor: .bottomTrailing).combined(with: .opacity))
    }
}

enum CanvasPhases {
    case welcome
    case tryit
    case send
    case great
    case empty
    case click
    case newset
}
