import SwiftUI

struct HUDView: View {
    @EnvironmentObject var playgroundData: DataModel
    
    var animation: Namespace.ID
    
    @State var messageCondition: (() -> (HUDPhases?))?
    @State var helpState: (() -> ())?
    
    @State var text: String = ""
    @State var definingBy: Definitions = .enumeration
    
    let setStyles = [(name: "A", color: Color.playgroundTheme.blue),
                     (name: "B", color: Color.playgroundTheme.green),
                     (name: "C", color: Color.playgroundTheme.yellow),
                     (name: "D", color: Color.playgroundTheme.orange)]
    @State var currentSetStyleIndex = 0
    
    var availableSetStylesIndexes: [Int]  {
        let usedStyles = playgroundData.currentSets.map { (name: $0.name, color: $0.color) }
        let availableStyles = setStyles.filter { set in !usedStyles.contains { $0 == set } }
        return availableStyles.map { set in setStyles.firstIndex { $0 == set }! }
    }
    
    var currentSetStyle: (name: String, color: Color) {
        setStyles[currentSetStyleIndex]
    }
    
    @State var currentMenu: HUDMenus?
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            VStack(alignment: .trailing) {
                Spacer()
                messages
                toolbar
            }
            
            HStack(alignment: .top) {
                if currentMenu != nil {
                    Group {
                        switch currentMenu! {
                        case .fileSelection:
                            fileSelectionMenu
                        case .emptyCanvas:
                            emptyCanvasMenu
                        case .help:
                            helpMenu
                        }
                    }.frame(width: 270)
                } else {
                    menus
                }
                
                Spacer()
                
                counter
            }
        }.padding(30)
        .shadow(color: Color.black.opacity(0.05), radius: 10, x: 5, y: 5)
        .frame(width: playgroundRect.width, height: playgroundRect.height)
        .onChange(of: text) { _ in
            dismissMenu()
            evaluateCondition()
        }.onChange(of: playgroundData.activePopover) { _ in
            dismissMenu()
            evaluateCondition()
        }.onChange(of: playgroundData.userSetFiles) { _ in
            dismissMenu()
            evaluateCondition()
        }
    }
    
    func evaluateCondition() {
        if messageCondition != nil {
            if let result = messageCondition!() {
                playgroundData.currentCanvasPhase = result
            }
        }
    }
    
    @ViewBuilder
    var messages: some View {
        switch playgroundData.currentCanvasPhase {
        case .welcome:
            HUDMessageView(text: "Welcome to the 􀮋 Canvas!/ Here is where you will play with sets. ", nextPhase: .buttons, animation: animation)
        case .buttons:
            HUDMessageView(text: "You can 􀧐 pan and 􀊬 zoom with drags and mouse gestures if you feel like you need to./\n\nThere are also a few buttons that will surely become handy soon, such as 􀈘 File selection, 􀈔 Empty Canvas and 􀁝 Help.     ", nextPhase: .toolbar, animation: animation)
        case .toolbar:
            HUDMessageView(text: "You might've already noticed that there's a nice lil' toolbar right below me./ You can use it to create your first set!/\n\nJust 􀇳 type the numbers you want to add to it, separated by commas. ", onAppear: {
                helpState = {
                    text = "2, 3, 5"
                }
                
                messageCondition = {
                    if playgroundData.currentSets.count > 0 {
                        if playgroundData.currentSets.last!.elements.count == 0 {
                            DispatchQueue.main.asyncAfter(deadline: .now()+8, execute: { playgroundData.currentCanvasPhase = .empty })
                        } else {
                            DispatchQueue.main.asyncAfter(deadline: .now()+8, execute: { playgroundData.currentCanvasPhase = .click })
                        }
                        return .great
                    } else {
                        return text.count > 6 ? .send : nil
                    }
                }
            })
        case .send:
            HUDMessageView(text: "Now hit 􀁧 or return to send your set to the.../ set manager. ", onAppear: {
                helpState = {
                    playgroundData.currentSets = [UserMathSet(name: currentSetStyle.name, color: currentSetStyle.color, elements: [2, 3, 5])]
                    playgroundData.parseSets()
                }
                
                messageCondition = {
                    if playgroundData.currentSets.count > 0 {
                        if playgroundData.currentSets.last!.elements.count == 0 {
                            DispatchQueue.main.asyncAfter(deadline: .now()+8, execute: { playgroundData.currentCanvasPhase = .empty })
                        } else {
                            DispatchQueue.main.asyncAfter(deadline: .now()+8, execute: { playgroundData.currentCanvasPhase = .click })
                        }
                        return .great
                    } else {
                        return nil
                    }
                }
            })
        case .great:
            HUDMessageView(text: "Great! 🤖/\n\nSee your shiny new set being drawn there?/ That type of drawing is known as a Venn diagram. ", nextPhase: .click, onAppear: {
                helpState = nil
                messageCondition = nil
            })
        case .empty:
            HUDMessageView(text: "Oopsie! 😅/\n\nThe set you have created is actually an empty set! But, don't worry, you'd get to that part eventually. For now, keep in mind that empty sets can be represented by the symbol Ø.", onAppear: {
                helpState = nil
                messageCondition = nil
            })
        case .click:
            HUDMessageView(text: "You can now try to click on it to view more information.", onAppear: {
                helpState = { playgroundData.activePopover = playgroundData.parsedObjects.first?.id }
                messageCondition = { playgroundData.activePopover != nil ? .sharing : nil }
            })
        case .sharing:
            HUDMessageView(text: "Awesome! 🎉/\n\nNow go ahead and create an entirely new set, sharing some of the items of this already existing set, to see what happens. ", onAppear: {
                messageCondition = { playgroundData.parsedObjects.contains { $0 is MathIntersection } ? .intersection : nil }
            })
        case .intersection:
            HUDMessageView(text: "Hooray!/\nYou're on fire! 🔥/\n\nThis new diagram that resulted from your creation is called an 􀫲 Intersection! The bubble in the middle of it can be represented by ")
        }
    }
    
    var toolbar: some View {
        VStack(spacing: 0) {
            sets.frame(maxHeight: playgroundData.parsedObjects.count > 0 ? 10 : 0)
            
            HStack(spacing: 0) {
                notationSelector
                input
                send
            }.frame(height: 50)
        }.cornerRadius(15.0)
        .shadow(color: colorScheme == .dark ? currentSetStyle.color.opacity(0.1) : .clear, radius: 10)
    }
    
    var sets: some View {
        HStack(alignment: .bottom, spacing: 0) {
            ForEach(playgroundData.parsedObjects, id: \.id) { object in
                HUDMathObjectView(object: object, isFinal: true)
            }
        }.overlay(LinearGradient(gradient: Gradient(colors: [Color.white.opacity(0.2), Color.white.opacity(0.05)]), startPoint: .top, endPoint: .center).allowsHitTesting(false))
    }
    
    var notationSelector: some View {
        ZStack {
            colorScheme == .dark ? Color.playgroundTheme.black : Color.white
            
            Menu {
                Text("Notation")
                
                Button(action: {
                    definingBy = .enumeration
                }) {
                    Text("Enumeration \(definingBy == .enumeration ? "􀆅" : "")")
                }
            } label: {
                EmptyView()
                    .frame(width: 50, height: 50)
            }.menuStyle(BorderlessButtonMenuStyle())
            .opacity(0.08)
            
            Image(systemName: definingBy == .enumeration ? "number" : "rectangle.portrait.arrowtriangle.2.inward")
                .font(.system(size: 22, weight: .medium))
                .foregroundColor(colorScheme == .dark ? Color.playgroundTheme.white : Color.playgroundTheme.gray)
                .allowsHitTesting(false)
        }.aspectRatio(1.0, contentMode: .fit)
    }
    
    var styleSelector: some View {
        ZStack {
            Menu {
                Text("Style")
                
                ForEach(0..<setStyles.count) { index in
                    Button(action: {
                        withAnimation {
                            currentSetStyleIndex = index
                        }
                    }) {
                        Text("Set \(setStyles[index].name)").foregroundColor(getColorTones(for: setStyles[index].color).foreground) + Text(currentSetStyleIndex == index ? " 􀆅" : "")
                    }.disabled(!availableSetStylesIndexes.contains(index))
                }
            } label: {
                EmptyView()
                    .frame(width: 50, height: 50)
            }.menuStyle(BorderlessButtonMenuStyle())
            .opacity(0.08)
            
            Text(currentSetStyle.name)
                .font(.system(size: 20, weight: .regular, design: .serif))
                .foregroundColor(getColorTones(for: currentSetStyle.color).foreground)
                .allowsHitTesting(false)
        }.aspectRatio(1.0, contentMode: .fit)
    }
    
    var input: some View {
        ZStack(alignment: .leading) {
            getColorTones(for: currentSetStyle.color).background
            
            styleSelector
            
            HStack {
                Text("= {")
                    .foregroundColor(getColorTones(for: currentSetStyle.color).foreground)
                    .font(.system(size: 20, weight: .regular, design: .serif))
                
                ZStack(alignment: .leading) {
                    TextField("2, 3, 5...", text: $text)
                        .textFieldStyle(PlainTextFieldStyle())
                    
                    (Text(text != "" ? text : "2, 3, 5...").foregroundColor(.clear) +
                        Text(" }").font(.system(size: 20, weight: .regular, design: .serif))
                        .foregroundColor(getColorTones(for: currentSetStyle.color).foreground))
                        .lineLimit(1).allowsHitTesting(false)
                }.font(Font(getFontWithAlignedNumbers(font: "Raleway", size: 20)))
            }.padding(.horizontal, 15)
            .padding(.leading, 20)
        }
    }
    
    func getColorTones(for color: Color) -> (background: Color, foreground: Color) {
        (background: Color(hue: Double(NSColor(color).hueComponent), saturation: colorScheme == .dark ? 0.1 : 0.05, brightness: colorScheme == .dark ? 0.3 : 1.0), foreground: Color(hue: Double(NSColor(color).hueComponent), saturation: colorScheme == .dark ? 0.6 : 0.5, brightness: colorScheme == .dark ? 0.9 : 0.4))
    }
    
    var send: some View {
        ZStack {
            colorScheme == .dark ? Color.playgroundTheme.black : Color.white
            
            Button("", action: addSet).opacity(0)
                .allowsHitTesting(false)
                .keyboardShortcut(.return, modifiers: [])
            
            Button(action: addSet) {
                Image(systemName: "arrowtriangle.up.circle.fill")
                    .font(.system(size: 25))
                    .foregroundColor(currentSetStyle.color)
            }.buttonStyle(PlainButtonStyle())
        }.aspectRatio(1.0, contentMode: .fit)
        .disabled(playgroundData.currentSets.count >= setStyles.count-1)
    }
    
    func addSet() {
        if playgroundData.currentSets.count < 3 {
            let elements = Set(text.components(separatedBy: ",").compactMap { Float($0.trimmingCharacters(in: .whitespaces)) })
            
            withAnimation {
                playgroundData.currentSets.append(UserMathSet(name: currentSetStyle.name, color: currentSetStyle.color, elements: elements))
                playgroundData.parseSets()
                
                if !availableSetStylesIndexes.contains(currentSetStyleIndex) {
                    currentSetStyleIndex = availableSetStylesIndexes[0]
                }
            }
            
            text = ""
        }
    }
    
    var menus: some View {
        VStack {
            Button(action: {
                withAnimation(.spring(response: 0.35, dampingFraction: 0.65)) {
                    currentMenu = .fileSelection
                }
            }) {
                HUDButton(systemName: "folder.fill", animation: animation)
            }.buttonStyle(PlainButtonStyle())
            .help("File selection")
            
            Button(action: {
                withAnimation(.spring(response: 0.35, dampingFraction: 0.65)) {
                    currentMenu = .emptyCanvas
                }
            }) {
                HUDButton(systemName: "trash.fill", animation: animation)
            }.buttonStyle(PlainButtonStyle())
            .help("Empty canvas")
            
            Button(action: {
                withAnimation(.spring(response: 0.35, dampingFraction: 0.65)) {
                    currentMenu = .help
                }
            }) {
                HUDButton(systemName: "questionmark", animation: animation).font(Font.body.bold())
            }.buttonStyle(PlainButtonStyle())
            .help("Help")
            .disabled(helpState == nil)
        }
    }
    
    var fileSelectionMenu: some View {
        ZStack(alignment: .topLeading) {
            HUDMenuBackground(cornerRadius: 25.0)
                .matchedGeometryEffect(id: "Background-folder.fill", in: animation)
            
            VStack(alignment: .leading, spacing: 5) {
                HUDMenuHeader(title: "File selection", systemName: "folder.fill", animation: animation)
                    .font(Font.custom("Raleway", size: 20).weight(.bold))
                    .frame(height: 18)
                Spacer()
                
                VStack(spacing: 5) {
                    ForEach(playgroundData.userSetFiles) { file in
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.1)) {
                                playgroundData.currentFileIndex = playgroundData.userSetFiles.firstIndex(of: file)!
                                playgroundData.parseSets()
                            }
                        }) {
                            HUDSelectionButton(file: file)
                        }.buttonStyle(PlainButtonStyle())
                    }
                }
            }.foregroundColor(colorScheme == .dark ? Color.playgroundTheme.white : Color.playgroundTheme.gray)
            .padding(20)
        }.frame(height: 285)
        .onTapGesture(perform: dismissMenu)
    }
    
    var emptyCanvasMenu: some View {
        ZStack(alignment: .topLeading) {
            HUDMenuBackground(cornerRadius: 25.0)
                .matchedGeometryEffect(id: "Background-trash.fill", in: animation)
            
            VStack(alignment: .leading) {
                HUDMenuHeader(title: "Empty Canvas", systemName: "trash.fill", animation: animation)
                    .font(Font.custom("Raleway", size: 20).weight(.bold))
                    .frame(height: 18)
                Spacer()
                
                Text("Are you sure you want to empty the 􀮋 Canvas? You'll lose all of your precious sets ").font(Font.custom("Raleway", size: 13).weight(.medium)) + Text("forever.").font(Font.system(size: 13).italic())
                
                Spacer()
                HStack {
                    Button(action: dismissMenu) {
                        HUDCapsuleButton(label: "Cancel")
                    }.buttonStyle(PlainButtonStyle())
                    
                    Button(action: {
                        withAnimation {
                            playgroundData.currentSets = []
                            playgroundData.parsedObjects = []
                        }
                        
                        dismissMenu()
                    }) {
                        HUDCapsuleButton(label: "Yes", style: .destructive)
                    }.buttonStyle(PlainButtonStyle())
                }.frame(height: 35)
                .font(Font.custom("Raleway", size: 16).weight(.semibold))
            }.foregroundColor(colorScheme == .dark ? Color.playgroundTheme.white : Color.playgroundTheme.gray)
            .padding(20)
        }.frame(height: 165)
        .onTapGesture(perform: dismissMenu)
    }
    
    var helpMenu: some View {
        ZStack(alignment: .topLeading) {
            HUDMenuBackground(cornerRadius: 25.0)
                .matchedGeometryEffect(id: "Background-questionmark", in: animation)
            
            VStack(alignment: .leading) {
                HUDMenuHeader(title: "Help", systemName: "questionmark", animation: animation)
                    .font(Font.custom("Raleway", size: 20).weight(.bold))
                    .frame(height: 18)
                Spacer()
                
                Text("If you are stuck or don't know what to do to proceed, Seth can give you a little hand. ")
                    .font(Font.custom("Raleway", size: 13).weight(.medium))
                
                Spacer()
                Button(action: {
                    if helpState != nil {
                        helpState!()
                        helpState = nil
                    }
                    
                    dismissMenu()
                }) {
                    HUDCapsuleButton(label: "Get help", style: .help)
                }.buttonStyle(PlainButtonStyle())
                .frame(height: 35)
                .font(Font.custom("Raleway", size: 16).weight(.semibold))
            }.foregroundColor(colorScheme == .dark ? Color.playgroundTheme.white : Color.playgroundTheme.gray)
            .padding(20)
        }.frame(height: 165)
        .onTapGesture(perform: dismissMenu)
    }
    
    func dismissMenu() {
        withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
            currentMenu = nil
        }
    }
    
    var counter: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25.0).fill(colorScheme == .dark ? Color.playgroundTheme.black : Color.white)
            
            HStack(spacing: 0) {
                Image(nsImage: NSImage(named: "Set Bits.png")!)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                Spacer()
                
                HStack(spacing: 0) {
                    Spacer()
                    Text(String(playgroundData.currentSets.count))
                        .foregroundColor(colorScheme == .dark ? Color.playgroundTheme.white : Color.playgroundTheme.gray)
                        .font(Font(getFontWithAlignedNumbers(font: "Raleway", size: 36)).weight(.bold))
                        .fixedSize()
                    Spacer()
                }
            }.padding(10)
            .foregroundColor(Color.playgroundTheme.gray)
        }.frame(width: 100, height: 60)
        .animation(nil)
    }
}

struct HUDMathObjectView: View {
    @EnvironmentObject var playgroundData: DataModel
    
    var object: MathObject
    
    var isFinal: Bool = false
    
    var body: some View {
        Group {
            if object is MathSet {
                HUDMathSetView(set: object as! MathSet)
            } else if object is MathIntersection {
                HUDMathIntersectionView(intersection: object as! MathIntersection)
            } else if object is MathContainment {
                HUDMathContainmentView(containment: object as! MathContainment)
            } else if object is MathThreeway {
                HUDMathThreewayView(threeway: object as! MathThreeway)
            }
        }.allowsHitTesting(isFinal)
        .onTapGesture {
            if isFinal {
                playgroundData.activePopover = object.id
            }
        }
    }
}

struct HUDMathSetView: View {
    var set: MathSet
    
    var body: some View {
        self.set.userSet.color
    }
}

struct HUDMathIntersectionView: View {
    var intersection: MathIntersection
    
    var body: some View {
        HStack(spacing: 0) {
            HUDMathObjectView(object: intersection.lhs)
            HUDMathObjectView(object: intersection.rhs)
        }
    }
}

struct HUDMathContainmentView: View {
    var containment: MathContainment
    
    var body: some View {
        HStack(spacing: 0) {
            HUDMathObjectView(object: containment.outer)
            ForEach(containment.inner, id: \.id) { object in
                HUDMathObjectView(object: object)
            }
        }
    }
}

struct HUDMathThreewayView: View {
    var threeway: MathThreeway
    
    var body: some View {
        HStack(spacing: 0) {
            HUDMathObjectView(object: threeway.lhs)
            HUDMathObjectView(object: threeway.top)
            HUDMathObjectView(object: threeway.rhs)
        }
    }
}

struct HUDMessageView: View {
    @EnvironmentObject var playgroundData: DataModel
    
    var text: String
    
    var nextPhase: HUDPhases? = nil
    var delay: Double = 3.0
    var onAppear: () -> () = {}
    
    var animation: Namespace.ID?
    
    @State var showingSpeech = false
    @State var paused = false
    
    @State var offsetMovement: CGFloat = 1.0
    let timer = Timer.publish(every: 1.25, on: .main, in: .common).autoconnect()
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack {
            Spacer()
            
            if showingSpeech {
                speech
            }
            
            HStack {
                Spacer()
                SethView(paused: $paused)
                    .frame(width: 165)
                    .offset(y: offsetMovement*2.5)
                    .animation(.easeInOut(duration: 1.5))
                    .matchedGeometryEffect(id: "Seth", in: animation ?? Namespace().wrappedValue)
            }
        }.frame(width: 230)
        .onAppear {
            onAppear()
            
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                showingSpeech = true
            }
            
            withAnimation(.easeInOut(duration: 2.0)) {
                offsetMovement = -offsetMovement
            }
        }.onReceive(timer) { _ in
            withAnimation(Animation.easeInOut(duration: 2.0).delay(0.3)) {
                offsetMovement = -offsetMovement
            }
        }.onHover { over in
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                showingSpeech = !over
                paused = over
            }
        }
    }
    
    var speech: some View {
        SpeechView(text: text, completion: {
            paused = true
            DispatchQueue.main.asyncAfter(deadline: .now()+delay, execute: {
                if nextPhase != nil {
                    playgroundData.currentCanvasPhase = nextPhase!
                }
            })
        }, arrowPosition: .bottomTrailing, lineWidth: 10.0, innerPadding: 15)
        .font(Font.custom("Raleway", size: 16).weight(.semibold))
        .transition(AnyTransition.scale(scale: 0.5, anchor: .bottomTrailing).combined(with: .opacity))
        .offset(y: offsetMovement*2.5)
        .allowsHitTesting(false)
    }
}

enum HUDPhases {
    case welcome
    case buttons
    case toolbar
    case send
    case great
    case empty
    case click
    case sharing
    case intersection
}


struct HUDButton: View {
    var systemName: String
    var animation: Namespace.ID?
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25.0).fill(colorScheme == .dark ? Color.playgroundTheme.black : Color.white)
                .matchedGeometryEffect(id: "Background-\(systemName)", in: animation ?? Namespace().wrappedValue)
            Image(systemName: systemName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .foregroundColor(colorScheme == .dark ? Color.playgroundTheme.white : Color.playgroundTheme.gray)
                .matchedGeometryEffect(id: systemName, in: animation ?? Namespace().wrappedValue)
                .padding(14)
        }.frame(width: 50, height: 50)
    }
}

struct HUDMenuHeader: View {
    var title: String
    var systemName: String
    
    var animation: Namespace.ID?
    
    var body: some View {
        HStack {
            Image(systemName: systemName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .matchedGeometryEffect(id: systemName, in: animation ?? Namespace().wrappedValue)
            Text(title)
        }
    }
}

struct HUDCapsuleButton: View {
    var label: String = ""
    var style: HUDCapsuleStyle = .normal
    
    @Environment(\.colorScheme) var colorScheme
    
    var styleColor: Color {
        switch style {
        case .normal:
            return colorScheme == .dark ? Color.playgroundTheme.gray : Color.playgroundTheme.white
        case .selected:
            return Color.playgroundTheme.blue
        case .destructive:
            return Color.playgroundTheme.orange
        case .help:
            return Color.playgroundTheme.green
        }
    }
    
    var body: some View {
        ZStack {
            Capsule().fill(styleColor)
            Text(label).foregroundColor(style != .normal ? Color.white : Color.primary)
        }.shadow(color: colorScheme == .dark ? styleColor.opacity(0.3) : .clear, radius: 8)
    }
}

enum HUDCapsuleStyle {
    case normal
    case selected
    case destructive
    case help
}

struct HUDSelectionButton: View {
    @EnvironmentObject var playgroundData: DataModel
    
    var file: UserFile
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        ZStack {
            HUDCapsuleButton(style: file == playgroundData.currentFile ? .selected : .normal)
            
            HStack(spacing: 4) {
                Text(file.name)
                    .font(Font(getFontWithAlignedNumbers(font: "Raleway", size: 16)).weight(.medium))
                    .padding(.leading, 5)
                Spacer()
                
                if file.userSets.count > 0 {
                    Image(nsImage: NSImage(named: "Set Bits.png")!)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                    Text(String(file.userSets.count))
                        .font(Font(getFontWithAlignedNumbers(font: "Raleway", size: 14)).weight(.bold))
                } else {
                    Text("-")
                        .font(Font.custom("Raleway", size: 14).weight(.bold))
                }
                
                Spacer()
                Image(systemName: file == playgroundData.currentFile ? "checkmark.circle.fill" : "circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            }.padding(10)
        }.foregroundColor(file == playgroundData.currentFile || colorScheme == .dark ? Color.playgroundTheme.white : Color.playgroundTheme.black)
    }
}

struct HUDMenuBackground: View {
    var cornerRadius: CGFloat
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        RoundedRectangle(cornerRadius: cornerRadius)
            .fill(colorScheme == .dark ? Color.playgroundTheme.black : Color.white)
    }
}

enum HUDMenus {
    case fileSelection
    case emptyCanvas
    case help
}
