// This file contains all helper elements that don't fit anywhere else

import Foundation
import SwiftUI

func getFontWithAlignedNumbers(font: String, size: CGFloat) -> CTFont {
    let font = CTFontCreateWithName(font as CFString, size, nil)

    let fontFeatureSettings: [CFDictionary] = [
        [
            kCTFontFeatureTypeIdentifierKey: kNumberCaseType,
            kCTFontFeatureSelectorIdentifierKey: 1,
        ] as CFDictionary
    ]

    let fontDescriptor = CTFontDescriptorCreateWithAttributes([
        kCTFontFeatureSettingsAttribute: fontFeatureSettings
    ] as CFDictionary)

    let fontWithFeatures = CTFontCreateCopyWithAttributes(font, size, nil, fontDescriptor)
    return fontWithFeatures
}

extension Color {
    struct playgroundTheme {
        static var purple: Color { Color(#colorLiteral(red: 0.3450980392, green: 0.3882352941, blue: 0.9725490196, alpha: 1)) }
        static var green: Color { Color(#colorLiteral(red: 0.2274509804, green: 0.8509803922, blue: 0.5764705882, alpha: 1)) }
        static var yellow: Color { Color(#colorLiteral(red: 1, green: 0.8901960784, blue: 0.5058823529, alpha: 1)) }
        static var blue: Color { Color(#colorLiteral(red: 0.7921568627, green: 1, blue: 1, alpha: 1)) }
        static var white: Color { Color(#colorLiteral(red: 1, green: 0.9921568627, blue: 0.9803921569, alpha: 1)) }
        static var black: Color { Color(#colorLiteral(red: 0.300863564, green: 0.284390837, blue: 0.2738331556, alpha: 1)) }
    }
}
