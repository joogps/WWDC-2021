// This file contains the declaration of the data structure

import SwiftUI

class DataModel: ObservableObject {
    @Published var currentScreen: Screens = .canvas
    
    @Published var currentIntroPhase: IntroPhases = .hi
    @Published var currentCanvasPhase: CanvasPhases = .welcome
    
    @Published var userSets = [UserMathSet]()
    @Published var parsedObjects = [MathObject]()
    
    @Published var showedPopover: Bool = false
    
    // not proud of this manual algorithm either. I know it could be recursive
    
    func parseSets() {
        parsedObjects = []
        
        for userSet in userSets {
            parsedObjects.append(MathSet(size: userSet.count == 0 ? 20 : CGFloat(userSet.count*30), item: userSet))
        }
        
        if parsedObjects.count == 2 {
            checkIntersection(index1: 0, index2: 1)
        }
        
        if parsedObjects.count == 3 {
            checkThreeway(index1: 0, index2: 1, index3: 2)
            if parsedObjects.count == 1 {
                return
            }
            
            let set1 = parsedObjects[0] as! MathSet
            let set2 = parsedObjects[1] as! MathSet
            let set3 = parsedObjects[2] as! MathSet
            
            let intersection1 = set1.item.elements.intersection(set2.item.elements)
            let intersection2 = set1.item.elements.intersection(set3.item.elements)
            let intersection3 = set2.item.elements.intersection(set3.item.elements)
            
            let intersections = (intersection1.count > 0 ? 1 : 0) +
                (intersection2.count > 0 ? 1 : 0) +
                (intersection3.count > 0 ? 1 : 0)
            
            if intersections > 1 {
                if intersection1.count + intersection2.count > 1 {
                    checkComplexIntersection(index1: 1, index2: 0, index3: 2)
                } else if intersection1.count + intersection3.count > 1 {
                    checkComplexIntersection(index1: 0, index2: 1, index3: 2)
                } else if intersection2.count + intersection3.count > 1 {
                    checkComplexIntersection(index1: 1, index2: 2, index3: 0)
                }
            } else {
                if parsedObjects.count == 3 { checkIntersection(index1: 0, index2: 1) }
                if parsedObjects.count == 3 { checkIntersection(index1: 0, index2: 2) }
                if parsedObjects.count == 3 { checkIntersection(index1: 1, index2: 2) }
            }
        }
    }
    
    func checkIntersection(index1: Int, index2: Int) {
        let set1 = parsedObjects[index1] as! MathSet
        let set2 = parsedObjects[index2] as! MathSet
        
        let intersection = set1.item.elements.intersection(set2.item.elements)
        if intersection.count > 0 {
            if intersection.count == set1.item.count || intersection.count == set2.item.count {
                parsedObjects.removeSubrange(index1...index2)
                parsedObjects.append(MathContainment(inner: set1, outer: set2))
            } else {
                parsedObjects.removeSubrange(index1...index2)
                
                let intersectionOffset = CGFloat(intersection.count)*30
                parsedObjects.append(MathIntersection(gap: intersectionOffset, lhs: set1, rhs: set2))
            }
        }
    }
    
    func checkComplexIntersection(index1: Int, index2: Int, index3: Int) {
        let set1 = parsedObjects[index1] as! MathSet
        let set2 = parsedObjects[index2] as! MathSet
        let set3 = parsedObjects[index3] as! MathSet
        
        let intersection1 = set1.item.elements.intersection(set2.item.elements)
        let intersection2 = set2.item.elements.intersection(set3.item.elements)
        
        parsedObjects = []
        
        if intersection1.count == set1.item.count {
            parsedObjects.append(MathIntersection(gap: CGFloat(intersection2.count)*30, lhs: MathContainment(inner: set1, outer: set2), rhs: set3))
        } else if intersection2.count == set3.item.count {
            parsedObjects.append(MathIntersection(gap: CGFloat(intersection1.count)*30, lhs: set2, rhs: MathContainment(inner: set3, outer: set1)))
        } else {
            parsedObjects.append(MathIntersection(gap: CGFloat(intersection1.count)*30, lhs: set1, rhs: MathIntersection(gap: CGFloat(intersection2.count)*30, lhs: set2, rhs: set3)))
        }
    }
    
    func checkThreeway(index1: Int, index2: Int, index3: Int) {
        let set1 = parsedObjects[index1] as! MathSet
        let set2 = parsedObjects[index2] as! MathSet
        let set3 = parsedObjects[index3] as! MathSet
        
        let intersection = set1.item.elements.intersection(set2.item.elements).intersection(set3.item.elements)
        
        if intersection.count > 0 {
            parsedObjects.removeSubrange(index1...index3)
            
            print(set1.item.elements.count-intersection.count)
            
            let offset = MathThreewayOffset(top: CGFloat((set1.item.elements.count-intersection.count)*15),
                                            lhs: CGFloat((set2.item.elements.count-intersection.count)*15),
                                            rhs: CGFloat((set3.item.elements.count-intersection.count)*15))
            
            print(offset.top, offset.lhs, offset.rhs)
            
            parsedObjects.append(MathThreeway(offset: offset, top: set1, lhs: set2, rhs: set3))
        }
    }
}

protocol MathObject {
    var id: UUID { get }
}

struct MathSet: MathObject {
    var id = UUID()
    
    var size: CGFloat = .zero
    
    var item: UserMathSet
}

struct MathIntersection: MathObject {
    var id = UUID()
    
    var gap: CGFloat = .zero
    
    var lhs: MathObject
    var rhs: MathObject
}

struct MathContainment: MathObject {
    var id = UUID()
    
    var inner: MathObject
    var outer: MathObject
}

struct MathThreeway: MathObject {
    var id = UUID()
    
    var offset: MathThreewayOffset = .zero
    
    var top: MathObject
    var lhs: MathObject
    var rhs: MathObject
}

struct MathThreewayOffset {
    var top: CGFloat
    var lhs: CGFloat
    var rhs: CGFloat
    
    static var zero: MathThreewayOffset {
        MathThreewayOffset(top: .zero, lhs: .zero, rhs: .zero)
    }
}

struct UserMathSet: Equatable {
    var name: String
    var color: Color
    
    var elements = Set<Float>()
    var definedBy: Definitions = .enumeration
    
    var count: Int {
        elements.count
    }
    
    var parsedItems: String {
        elements.count > 0 ? "{\(elements.map { $0.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", $0) : String($0) }.joined(separator: ", "))}" : "Ø"
    }
}

enum Definitions {
    case enumeration
    case builder
}

enum Screens {
    case title
    case intro
    case canvas
}
