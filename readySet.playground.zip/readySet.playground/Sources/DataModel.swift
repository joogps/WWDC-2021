// This file contains the declaration of the playground's data structure

import SwiftUI

class DataModel: ObservableObject {
    @Published var currentScreen: Screens = .canvas
    
    @Published var currentIntroPhase: IntroPhases = .hi
    @Published var currentCanvasPhase: HUDPhases = .welcome
    
    @Published var userSetFiles = [UserFile(name: "File A"), UserFile(name: "File B"), UserFile(name: "File C"), UserFile(name: "File D"), UserFile(name: "File E")]
    @Published var currentFileIndex = 0
    
    var currentFile: UserFile {
        get {
            userSetFiles[currentFileIndex]
        } set {
            userSetFiles[currentFileIndex] = newValue
        }
    }
    
    var currentSets: [UserMathSet] {
        get {
            currentFile.userSets
        } set {
            currentFile.userSets = newValue
        }
    }
    
    @Published var parsedObjects = [MathObject]()
    
    @Published var activePopover: UUID? = nil
    
    // Not proud of this messy algorithm either.
    
    func parseSets() {
        parsedObjects = []
        
        for userSet in currentSets {
            parsedObjects.append(MathSet(size: userSet.count == 0 ? 20 : CGFloat(userSet.count*30), userSet: userSet))
        }
        
        if parsedObjects.count == 2 {
            checkIntersection(index1: 0, index2: 1)
        }
        
        if parsedObjects.count == 3 {
            checkThreeway(index1: 0, index2: 1, index3: 2)
            
            if parsedObjects.count != 1 {
                let set1 = parsedObjects[0] as! MathSet
                let set2 = parsedObjects[1] as! MathSet
                let set3 = parsedObjects[2] as! MathSet
                
                let intersection1 = set1.elements.intersection(set2.elements)
                let intersection2 = set1.elements.intersection(set3.elements)
                let intersection3 = set2.elements.intersection(set3.elements)
                
                let intersections = (intersection1.count > 0 ? 1 : 0) + (intersection2.count > 0 ? 1 : 0) + (intersection3.count > 0 ? 1 : 0)
                
                if intersections > 1 {
                    if intersection1.count * intersection2.count > 0 {
                        checkComplexIntersection(index1: 1, index2: 0, index3: 2)
                    } else if intersection1.count * intersection3.count > 0 {
                        checkComplexIntersection(index1: 0, index2: 1, index3: 2)
                    } else if intersection2.count * intersection3.count > 0 {
                        checkComplexIntersection(index1: 0, index2: 2, index3: 1)
                    }
                } else {
                    if parsedObjects.count == 3 { checkIntersection(index1: 0, index2: 1) }
                    if parsedObjects.count == 3 { checkIntersection(index1: 0, index2: 2) }
                    if parsedObjects.count == 3 { checkIntersection(index1: 1, index2: 2) }
                }
            }
        }
    }
    
    func checkIntersection(index1: Int, index2: Int) {
        let set1 = parsedObjects[index1] as! MathSet
        let set2 = parsedObjects[index2] as! MathSet
        
        let intersection = set1.elements.intersection(set2.elements)
        if intersection.count > 0 {
            if intersection.count == set1.userSet.count || intersection.count == set2.userSet.count {
                parsedObjects.removeSubrange(index1...index2)
                if set1.elements.count < set2.elements.count {
                    parsedObjects.append(MathContainment(inner: [set1], outer: set2))
                } else {
                    parsedObjects.append(MathContainment(inner: [set2], outer: set1))
                }
            } else {
                parsedObjects.removeSubrange(index1...index2)
                
                let intersectionOffset = CGFloat(intersection.count)*30
                parsedObjects.append(MathIntersection(gap: intersectionOffset, lhs: set1, rhs: set2))
            }
        }
    }
    
    func checkComplexIntersection(index1: Int, index2: Int, index3: Int) {
        let set1 = parsedObjects[index1] as! MathSet
        let set2 = parsedObjects[index2] as! MathSet
        let set3 = parsedObjects[index3] as! MathSet
        
        let intersection1 = set1.elements.intersection(set2.elements)
        let intersection3 = set2.elements.intersection(set3.elements)
        
        parsedObjects = []
        
        if intersection1.count == set1.userSet.count {
            if intersection3.count == set3.userSet.count {
                parsedObjects.append(MathContainment(inner: [set1, set3], outer: set2))
            } else {
                parsedObjects.append(MathIntersection(gap: CGFloat(intersection3.count)*30, lhs: MathContainment(alignment: .leading, inner: [set1], outer: set2), rhs: set3))
            }
        } else if intersection3.count == set3.userSet.count {
            if intersection1.count == set1.userSet.count {
                print("test")
                parsedObjects.append(MathContainment(inner: [set3, set1], outer: set2))
            } else {
                parsedObjects.append(MathIntersection(gap: CGFloat(intersection1.count)*30, lhs: set1, rhs: MathContainment(alignment: .trailing, inner: [set3], outer: set2)))
            }
        } else {
            parsedObjects.append(MathIntersection(gap: CGFloat(intersection1.count)*30, lhs: set1, rhs: MathIntersection(gap: CGFloat(intersection3.count)*30, lhs: set2, rhs: set3)))
        }
    }
    
    func checkThreeway(index1: Int, index2: Int, index3: Int) {
        let set1 = parsedObjects[index1] as! MathSet
        let set2 = parsedObjects[index2] as! MathSet
        let set3 = parsedObjects[index3] as! MathSet
        
        let intersection = set1.elements.intersection(set2.elements).intersection(set3.elements)
        
        if intersection.count > 0 {
            parsedObjects.removeSubrange(index1...index3)
            
            print(set1.elements.count-intersection.count)
            
            let offset = MathThreewayOffset(top: CGFloat((set1.elements.count-intersection.count)*15),
                                            lhs: CGFloat((set2.elements.count-intersection.count)*15),
                                            rhs: CGFloat((set3.elements.count-intersection.count)*15))
            
            print(offset.top, offset.lhs, offset.rhs)
            
            parsedObjects.append(MathThreeway(offset: offset, top: set1, lhs: set2, rhs: set3))
        }
    }
}

protocol MathObject {
    var id: UUID { get }
}

struct MathSet: MathObject {
    var id: UUID = UUID()
    
    var size: CGFloat = .zero
    
    var userSet: UserMathSet
    var elements: Set<Float> {
        userSet.elements
    }
}

struct MathIntersection: MathObject {
    var id: UUID = UUID()
    
    var gap: CGFloat = .zero
    
    var lhs: MathObject
    var rhs: MathObject
}

struct MathContainment: MathObject {
    var id: UUID = UUID()
    
    var alignment: Alignment = .center
    
    var inner: [MathObject]
    var outer: MathObject
}

struct MathThreeway: MathObject {
    var id: UUID = UUID()
    
    var offset: MathThreewayOffset = .zero
    
    var top: MathObject
    var lhs: MathObject
    var rhs: MathObject
}

struct MathThreewayOffset {
    var top: CGFloat
    var lhs: CGFloat
    var rhs: CGFloat
    
    static var zero: MathThreewayOffset {
        MathThreewayOffset(top: .zero, lhs: .zero, rhs: .zero)
    }
}

struct UserMathSet: Equatable {
    var name: String
    var color: Color
    
    var elements = Set<Float>()
    var definedBy: Definitions = .enumeration
    
    var count: Int {
        elements.count
    }
    
    var parsedItems: String {
        elements.count > 0 ? "{ \(elements.sorted().map { $0.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", $0) : String($0) }.joined(separator: ", ")) }" : "Ø"
    }
}

struct UserFile: Equatable, Identifiable {
    var id = UUID()
    
    var name: String
    var userSets = [UserMathSet]()
}

enum Definitions {
    case enumeration
    case builder
}

enum Screens {
    case title
    case intro
    case canvas
}
