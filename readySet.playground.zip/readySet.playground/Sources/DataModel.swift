// This file contains the declaration of the data structure

import Foundation

class DataModel: ObservableObject {
    @Published var currentScreen: Screens = .canvas
}

enum Screens {
    case title
    case intro
    case canvas
}
