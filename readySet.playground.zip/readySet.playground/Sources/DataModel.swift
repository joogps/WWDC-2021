// This file contains the declaration of the data structure

import SwiftUI

class DataModel: ObservableObject {
    @Published var currentScreen: Screens = .canvas
    
    @Published var currentIntroPhase: IntroPhases = .hi
    @Published var currentCanvasPhase: CanvasPhases = .welcome
    
    @Published var mathSets = [MathSet]()
    @Published var showedPopover: Bool = false
    
    
    // not proud of this either
    
    func parseSets() {
        for (index, mathSet) in mathSets.enumerated() {
            mathSets[index].size = CGFloat(35+mathSet.count*20)
        }
        
        if mathSets.count == 3 {
            mathSets[0].position.x = playgroundSize.width*1/4
            mathSets[1].position.x = playgroundSize.width*2/4
            mathSets[2].position.x = playgroundSize.width*3/4
            
            let set1 = mathSets[0]
            let set2 = mathSets[1]
            let set3 = mathSets[2]
            
            let intersection = set1.items.intersection(set2.items).intersection(set3.items)
            
            if intersection.count > 0 {
                
            } else {
                checkIntersection(index1: 0, index2: 1)
                checkIntersection(index1: 1, index2: 2)
                checkIntersection(index1: 0, index2: 2)
            }
        }
        
        if mathSets.count == 2 {
            mathSets[0].position.x = playgroundSize.width*1/4
            mathSets[1].position.x = playgroundSize.width*3/4
            
            checkIntersection(index1: 0, index2: 1)
        }
    }
    
    func checkIntersection(index1: Int, index2: Int) {
        let set1 = mathSets[index1]
        let set2 = mathSets[index2]
        
        let intersection = set1.items.intersection(set2.items)
        if intersection.count > 0 {
            if intersection.count == set1.count || intersection.count == set2.count {
                mathSets[index1].position.x = playgroundSize.midX
                mathSets[index2].position.x = playgroundSize.midX
            } else {
                let intersectionSize = CGFloat(intersection.count*10)
                let totalSize = set1.size+set2.size-intersectionSize
                
                mathSets[index1].position.x = playgroundSize.midX-totalSize/2+set1.size/2
                mathSets[index1].intersections = mathSets
                
                mathSets[index2].position.x = playgroundSize.midX+totalSize/2-set2.size/2
                mathSets[index2].intersections = mathSets
            }
        }
    }
}

struct MathSet: Equatable {
    var name: String
    var color: Color
    
    var position: CGPoint = CGPoint(x: playgroundSize.midX, y: playgroundSize.midY)
    var size: CGFloat = .zero
    
    var definedBy: Definitions = .enumeration
    var items = Set<Float>()
    
    var intersections = [MathSet]()
    
    var count: Int {
        items.count
    }
    
    var parsedItems: String {
        items.count > 0 ? "{\(items.map { $0.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", $0) : String($0) }.joined(separator: ", "))}" : "Ø"
    }
}

enum Definitions {
    case enumeration
    case builder
}

enum Screens {
    case title
    case intro
    case canvas
}
