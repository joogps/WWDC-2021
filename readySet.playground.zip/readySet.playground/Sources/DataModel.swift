// This file contains the declaration of the data structure

import SwiftUI

class DataModel: ObservableObject {
    @Published var currentScreen: Screens = .canvas
    
    @Published var sets = [MathSet]()
}


struct MathSet {
    var name: String
    var color: Color
    
    var definedBy: Definitions = .enumeration
    var items = Set<Float>()
}

enum Definitions {
    case enumeration
    case builder
}

enum Screens {
    case title
    case intro
    case canvas
}
