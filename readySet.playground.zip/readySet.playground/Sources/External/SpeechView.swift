// This renders the speech view used for user interaction

import SwiftUI

struct SpeechView: View {
    let text: String
    let skip: Binding<Bool>
    let completion: (() -> ())?
    
    @Environment(\.colorScheme) var colorScheme
    
    init(text: String, skip: Binding<Bool> = .constant(false), completion: (() -> ())? = nil) {
        self.text = text
        self.skip = skip
        self.completion = completion
    }
    
    var body: some View {
        HStack {
            Spacer()
            typewriter
            Spacer()
        }.background(background)
    }
    
    var typewriter: some View {
        TypewriterText(text, skip: skip, completion: completion)
        .padding(30)
        .padding(.leading, 35)
    }
    
    var background: some View {
        ZStack {
            IrregularGradient(colors: [Color.playgroundTheme.blue, Color.playgroundTheme.yellow, Color.playgroundTheme.green, Color.playgroundTheme.purple], backgroundColor: Color.playgroundTheme.purple, speed: 5)
                .scaleEffect(1.2)
                .mask(SpeechBubble().stroke(Color.black, lineWidth: 16.0))
            SpeechBubble().fill(Color.white)
        }
    }
}

struct TypewriterText: View {
    let fullText: String
    let skip: Binding<Bool>
    let completion: (() -> ())?
    
    init(_ fullText: String, skip: Binding<Bool> = .constant(false), completion: (() -> ())? = nil) {
        self.fullText = fullText
        self.skip = skip
        self.completion = completion
    }
    
    @State var index = 0
    
    var formattedString: String {
        (skip.wrappedValue ? fullText[...] : fullText[..<String.Index(utf16Offset: index, in: fullText)]).replacingOccurrences(of: "/", with: "")
    }
    
    var body: some View {
        Text(fullText)
            .hidden()
            .background(Text(formattedString))
            .onAppear(perform: update)
    }
    
    func update() {
        if index < fullText.count && !skip.wrappedValue {
            let pause = fullText[String.Index(utf16Offset: index, in: fullText)] == "/" ? 0.5 : 0
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.05+pause) {
                index += 1
                update()
            }
        } else {
            completion?()
        }
    }
}

struct SpeechBubble: Shape {
    func path(in rect: CGRect) -> Path {
        var balloon = Path()
        
        let radius = CGFloat(30)
        
        let arrowSize = CGSize(width: 35, height: 35)
        let arrowRadius = CGFloat(3)
        
        // top left
        balloon.move(to: CGPoint(x: rect.minX+arrowSize.width, y: rect.minY+radius))
        balloon.addArc(center: CGPoint(x: rect.minX+radius+arrowSize.width, y: rect.minY+radius), radius: radius, startAngle: .degrees(180), endAngle: .degrees(270), clockwise: false)
        
        // top right
        balloon.addArc(center: CGPoint(x: rect.maxX-radius, y: rect.minY+radius), radius: radius, startAngle: .degrees(270), endAngle: .degrees(360), clockwise: false)
        
        // bottom right
        balloon.addArc(center: CGPoint(x: rect.maxX-radius, y: rect.maxY-radius), radius: radius, startAngle: .degrees(0), endAngle: .degrees(90), clockwise: false)
        
        // bottom left
        balloon.addArc(center: CGPoint(x: rect.minX+radius+arrowSize.width, y: rect.maxY-radius), radius: radius, startAngle: .degrees(90), endAngle: .degrees(180), clockwise: false)
        
        // arrow
        balloon.addLine(to: CGPoint(x: rect.minX+arrowSize.width, y: rect.minY+radius+arrowSize.height))
        balloon.addArc(center: CGPoint(x: rect.minX+arrowRadius, y: rect.minY+radius+arrowRadius), radius: arrowRadius, startAngle: .degrees(135), endAngle: .degrees(270), clockwise: false)
        
        balloon.closeSubpath()

        return balloon
    }
}

struct SpeechView_Previews: PreviewProvider {
    static var previews: some View {
        SpeechView(text: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.")
    }
}
