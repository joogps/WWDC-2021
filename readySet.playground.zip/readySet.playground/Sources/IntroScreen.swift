// This SwiftUI view presents the introduction screen of this playground experience

import SwiftUI

struct IntroScreen: View {
    @EnvironmentObject var playgroundData: DataModel
    
    var animation: Namespace.ID
    
    @Environment(\.colorScheme) var colorScheme
    
    @ViewBuilder
    var body: some View {
        ZStack {
            colorScheme == .dark ? Color.playgroundTheme.gray : Color.playgroundTheme.white
            
            switch playgroundData.currentIntroPhase {
            case .hi:
                IntroMessageView(text: "//Hi there!/ It's really nice to meet you in this, huh...// in this Xcode Playground, of course!", nextPhase: .seth, animation: animation)
            case .seth:
                IntroMessageView(text: "My name is Seth, by the way, and, according to my internal logs, I was designed to teach about set theory./\n\nOk then, set theory it is!", nextPhase: .know, animation: animation)
            case .know:
                IntroMessageView(text: "Now, don't get me wrong: I'm pretty sure YOU already know a LOT about set theory./ But I promise this will be fun nonetheless!", nextPhase: .remember, animation: animation)
            case .remember:
                IntroMessageView(text: "However, juuuust to remember, set theory is the branch of mathematics that studies.../ well, sets.", nextPhase: .sets, animation: animation)
            case .sets:
                IntroMessageView(text: "A set is a collection of non-repeatable objects./\n\nAnd, in fact, these objects can be anything you want them to be!/ In most cases though, these objects will be something relevant to the study of math (such as numbers or even sets themselves).", nextPhase: .defined, animation: animation)
            case .defined:
                IntroMessageView(text: "Sets can be defined with 􀫲 shapes and diagrams, or via special notations, always between 􀡅 curly braces./ You can see some examples below.  ", nextPhase: .talking, animation: animation)
            case .talking:
                IntroMessageView(text: "Enough of me talking though, what about going to the real deal?// Click on 􀁭 or press the right arrow key to access the 􀮋 Canvas.  ", nextPhase: .talking, action: {
                    withAnimation(.easeInOut) {
                        playgroundData.currentScreen = .canvas
                    }
                }, animation: animation)
            }
        }
    }
}

struct IntroMessageView: View {
    var text: String
    var nextPhase: IntroPhases
    var action: () -> () = {}
    
    @EnvironmentObject var playgroundData: DataModel
    
    var animation: Namespace.ID?
    
    @State var skip = false
    
    @State var showingSpeech = false
    @State var showingNext = false
    
    @State var offsetMovement: CGFloat = 1.0
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        ZStack(alignment: .trailing) {
            HStack(alignment: .top, spacing: 5) {
                SethView(paused: $showingNext).frame(width: 255)
                    .rotationEffect(.degrees(-5))
                    .offset(y: -20+offsetMovement*6)
                    .animation(.easeInOut(duration: 1.25))
                    .matchedGeometryEffect(id: "Seth", in: animation ?? Namespace().wrappedValue)
                
                Spacer()
                
                if showingSpeech {
                    speech
                }
            }.padding(60)
            
            VStack {
                Spacer()
                
                Button("", action: {
                    if showingNext {
                        goToNextPhase()
                    } else {
                        skip = true
                    }
                }).opacity(0)
                .allowsHitTesting(false)
                .keyboardShortcut(.rightArrow, modifiers: [])
                
                if showingNext {
                    next
                }
            }
        }.shadow(color: Color.black.opacity(0.05), radius: 10, x: 5, y: 5)
        .transition(.scale(scale: 0.95)).padding(20)
        .contentShape(Rectangle().size(playgroundRect.size))
        .onTapGesture {
            skip = true
        }.onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                showingSpeech = true
            }
            
            withAnimation(Animation.easeInOut(duration: 1.75)) {
                offsetMovement = -offsetMovement
            }
        }.onReceive(timer) { _ in
            withAnimation(Animation.easeInOut(duration: 1.75).delay(0.3)) {
                offsetMovement = -offsetMovement
            }
        }
    }
    
    var speech: some View {
        SpeechView(text: text, skip: $skip, completion: {
            withAnimation(.spring()) {
                showingNext = true
            }
        }).font(Font.custom("Raleway", size: 20).weight(.semibold))
        .transition(AnyTransition.scale(scale: 0.5, anchor: .topLeading).combined(with: .opacity))
        .offset(y: offsetMovement*3.5)
    }
    
    var next: some View {
        Button(action: goToNextPhase) {
            Image(systemName: "arrowtriangle.right.circle.fill")
                .resizable().frame(width: 68, height: 68)
                .foregroundColor(Color.playgroundTheme.blue)
                .overlay(LinearGradient(gradient: Gradient(colors: [Color.white.opacity(0.5), Color.white.opacity(0.1)]), startPoint: .topLeading, endPoint: .bottomTrailing).mask(Image(systemName: "arrowtriangle.right.circle.fill").resizable().frame(width: 68, height: 68)))
        }.buttonStyle(PlainButtonStyle())
        .shadow(color: colorScheme == .dark ? Color.playgroundTheme.blue.opacity(0.2) : .clear, radius: 8)
        .transition(AnyTransition.scale(scale: 0.6).combined(with: .opacity))
    }
    
    func goToNextPhase() {
        withAnimation {
            playgroundData.currentIntroPhase = nextPhase
        }
        action()
    }
}

enum IntroPhases {
    case hi
    case seth
    case know
    case remember
    case sets
    case defined
    case talking
}
