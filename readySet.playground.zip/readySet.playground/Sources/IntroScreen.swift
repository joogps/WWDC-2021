// This SwiftUI view presents the introduction screen of this playground experience

import SwiftUI

struct IntroScreen: View {
    @EnvironmentObject var appData: DataModel
    
    var animation: Namespace.ID
    @State var currentPhase: IntroPhases = .hi
    
    var body: some View {
        ZStack {
            switch currentPhase {
            case .hi:
                IntroMessageView(text: "//Hi there!/ It's really nice to meet you in this, huh...// in this Xcode Playground, of course!", nextPhase: .seth, currentPhase: $currentPhase, animation: animation)
            case .seth:
                IntroMessageView(text: "My name is Seth, by the way, and I'm pretty sure I was designed to teach about set theory!", nextPhase: .know, currentPhase: $currentPhase, animation: animation)
            case .know:
                IntroMessageView(text: "Now, don't get me wrong: I'm pretty sure YOU already know a LOT about math sets./ But here, it just hits different./ You'll see.", nextPhase: .remember, currentPhase: $currentPhase, animation: animation)
            case .remember:
                IntroMessageView(text: "But juuuust to remember, sets are collections of objects./ These objects can be anything you want them to be./ In math though, these objects will be numbers most of the time.", nextPhase: .defined, currentPhase: $currentPhase, animation: animation)
            case .defined:
                IntroMessageView(text: "Sets can be defined with 􀫲 shapes and diagrams, or via a special notation, always between 􀡅 curly braces.  ", nextPhase: .talking, currentPhase: $currentPhase, animation: animation)
            case .talking:
                IntroMessageView(text: "Enough of me talking though, what about going to the real deal?// Click on 􀁭 or press the right arrow key to access the 􀮋 Canvas.  ", nextPhase: .talking, action: {
                    withAnimation(.easeInOut) {
                        appData.currentScreen = .canvas
                    }
                }, currentPhase: $currentPhase, animation: animation)
            }
        }
    }
}

struct IntroMessageView: View {
    var text: String
    var nextPhase: IntroPhases
    var action: () -> () = {}
    
    @Binding var currentPhase: IntroPhases
    
    var animation: Namespace.ID
    
    @State var skip = false
    
    @State var showingSpeech = false
    @State var showingNext = false
    
    @State var offsetMovement: CGFloat = 1
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack(alignment: .trailing) {
            HStack(alignment: .top, spacing: 5) {
                SethView(paused: $showingNext).frame(width: 255)
                    .rotationEffect(.degrees(-5))
                    .offset(y: -20+offsetMovement*7.5)
                    .animation(Animation.easeInOut(duration: 1.25))
                    .matchedGeometryEffect(id: "Seth", in: animation)
                
                Spacer()
                
                if showingSpeech {
                    speech
                }
            }.padding(60)
            .shadow(color: Color.black.opacity(0.05), radius: 10, x: 5, y: 5)
            
            VStack {
                Spacer()
                if showingNext {
                    next
                }
            }
            
            Button("", action: {
                if showingNext {
                    currentPhase = nextPhase
                    action()
                } else {
                    skip = true
                }
            }).opacity(0)
            .allowsHitTesting(false)
            .keyboardShortcut(.rightArrow, modifiers: [])
        }.padding(20)
        .onTapGesture {
            skip = true
        }.onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                showingSpeech = true
            }
            
            withAnimation(Animation.easeInOut(duration: 1.75)) {
                offsetMovement = -offsetMovement
            }
        }.onReceive(timer) { _ in
            withAnimation(Animation.easeInOut(duration: 1.75)) {
                offsetMovement = -offsetMovement
            }
        }
    }
    
    var speech: some View {
        SpeechView(text: text, skip: $skip, completion: {
            withAnimation {
                showingNext = true
            }
        }).font(Font.custom("Raleway", size: 20).weight(.semibold))
        .foregroundColor(Color.playgroundTheme.black)
        .transition(AnyTransition.scale(scale: 0.5, anchor: .topLeading).combined(with: .opacity))
        .offset(y: offsetMovement*3.5)
    }
    
    var next: some View {
        Button(action: {
            currentPhase = nextPhase
            action()
        }) {
            Image(systemName: "arrowtriangle.right.circle.fill")
                .font(.system(size: 68))
                .foregroundColor(Color.playgroundTheme.blue)
                .overlay(LinearGradient(gradient: Gradient(colors: [Color.white.opacity(0.4), Color.white.opacity(0)]), startPoint: .topLeading, endPoint: .trailing))
        }.buttonStyle(PlainButtonStyle())
        .transition(AnyTransition.scale(scale: 0.5).combined(with: .opacity))
    }
}

enum IntroPhases {
    case hi
    case seth
    case know
    case remember
    case defined
    case talking
}
