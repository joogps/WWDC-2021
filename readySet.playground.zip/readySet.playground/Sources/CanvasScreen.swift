// This SwiftUI view presents the main and final screen of the playground experience

import SwiftUI

struct CanvasScreen: View {
    @EnvironmentObject var appData: DataModel
    
    var animation: Namespace.ID
    
    @State var scale: CGFloat = 1.0
    
    var body: some View {
        ZStack {
            ZStack {
                background
                
                ZStack {
                    ForEach(appData.sets, id: \.color) { set in
                        Circle()
                            .stroke(set.color,lineWidth: 4)
                            .background(Circle().foregroundColor(set.color.opacity(0.4)))
                            .frame(width: 200, height: 200)
                            .offset(x: (-1.5*150)+CGFloat(["A", "B", "C"].firstIndex(of: set.name)!*150))
                            .blendMode(.multiply)
                    }
                }
            }.scaleEffect(scale)
            
            SetBarView(animation: animation)
        }.gesture(MagnificationGesture().onChanged { value in
            let normalized = abs(value+1)
            scale = max(min(normalized/pow(2, normalized/500+1), 2), 0.5)
        }.onEnded { value in
            withAnimation {
                scale = 1.0
            }
        })
    }
    
    var background: some View {
        Image(nsImage: NSImage(named: "Background Tile.png")!)
            .resizable(resizingMode: .tile)
            .opacity(0.1)
            .frame(width: playgroundSize.width*2, height: playgroundSize.height*2)
    }
}

struct SetBarView: View {
    @EnvironmentObject var appData: DataModel
    
    var animation: Namespace.ID
    
    @State var currentPhase: CanvasPhases = .welcome
    @State var messageCondition: (() -> (CanvasPhases?))?
    
    @State var text: String = ""
    @State var definingBy: Definitions = .enumeration
    
    let setStyles = [(name: "A", color: Color.playgroundTheme.blue),
                     (name: "B", color: Color.playgroundTheme.green),
                     (name: "C", color: Color.playgroundTheme.yellow)]
    var currentSetStyle: (name: String, color: Color) {
        appData.sets.count < setStyles.count ? setStyles[appData.sets.count] : (name: "A", color: Color.playgroundTheme.blue)
    }
    
    var body: some View {
        VStack(alignment: .trailing) {
            Spacer()
            switch currentPhase {
            case .welcome:
                CanvasMessageView(text: "Welcome to the 􀮋 Canvas./ Here is where you will interact with sets. ", nextPhase: .tryit, currentPhase: $currentPhase, animation: animation)
            case .tryit:
                CanvasMessageView(text: "See the toolbar down here?/ You can use it to create a shiny new set!/ Just 􀇳 type the numbers you want to add to it, separated by commas. ", onAppear: {
                        messageCondition = { text.count > 3 ? .send : nil }
                    }, currentPhase: $currentPhase, animation: animation)
            case .send:
                CanvasMessageView(text: "Now just hit 􀁧 to send it! ", onAppear: {
                    messageCondition = { appData.sets.count > 0 ? .great : nil }
                }, currentPhase: $currentPhase, animation: animation)
            case .great:
                CanvasMessageView(text: "Great!/ See your new set being drawn there?/ That's what's known as a Venn diagram.", currentPhase: $currentPhase, animation: animation)
            }
            
            toolbar
        }.padding(30)
        .frame(width: playgroundSize.width, height: playgroundSize.height)
    }
    
    func evaluateCondition() {
        if messageCondition != nil {
            if let result = messageCondition!() {
                currentPhase = result
            }
        }
    }
    
    var toolbar: some View {
        VStack(spacing: 0) {
            sets.frame(maxHeight: appData.sets.count > 0 ? 10 : 0)
            
            HStack(spacing: 0) {
                menu
                input
            }.frame(height: 50)
        }.cornerRadius(15.0)
        .shadow(color: Color.black.opacity(0.05), radius: 10, x: 5, y: 5)
    }
    
    var sets: some View {
        HStack(alignment: .bottom, spacing: 0) {
            ForEach(appData.sets, id: \.color) { set in
                set.color
            }
        }.overlay(LinearGradient(gradient: Gradient(colors: [Color.white.opacity(0.3), Color.white.opacity(0)]), startPoint: .top, endPoint: .center))
    }
    
    var menu: some View {
        ZStack {
            Color.white
            
            Menu {
                Text("Notation")
                
                Button(action: {
                    definingBy = .enumeration
                }) {
                    Text("Enumeration \(definingBy == .enumeration ? "􀆅" : "")")
                }
                Button(action: {
                    definingBy = .builder
                }) {
                    Text("Set-builder \(definingBy == .builder ? "􀆅" : "")")
                }
            } label: {
                EmptyView()
                    .frame(width: 50, height: 50)
            }.menuStyle(BorderlessButtonMenuStyle())
            .opacity(0.1)
            
            Image(systemName: definingBy == .enumeration ? "number" : "rectangle.portrait.arrowtriangle.2.inward")
                .allowsHitTesting(false)
                .font(.system(size: 22, weight: .medium))
        }.aspectRatio(1.0, contentMode: .fit)
    }
    
    var input: some View {
        HStack(spacing: 0) {
            ZStack {
                Color(hue: Double(NSColor(currentSetStyle.color).hueComponent), saturation: 0.03, brightness: 1.0)
                
                HStack {
                    Text("\(currentSetStyle.name) = {")
                        .foregroundColor(Color(hue: Double(NSColor(currentSetStyle.color).hueComponent), saturation: 0.5, brightness: 0.4))
                        .font(.system(size: 20, weight: .regular, design: .serif))
                    
                    ZStack(alignment: .leading) {
                        TextField("2, 3, 5...", text: $text)
                            .textFieldStyle(PlainTextFieldStyle())
                            .onChange(of: text, perform: { _ in
                                evaluateCondition()
                            })
                        
                        (Text(text != "" ? text : "2, 3, 5...").foregroundColor(.clear) +
                        Text(" }")
                        .font(.system(size: 20, weight: .regular, design: .serif))
                        .foregroundColor(Color(hue: Double(NSColor(currentSetStyle.color).hueComponent), saturation: 0.5, brightness: 0.4))).lineLimit(1).allowsHitTesting(false)
                    }.font(Font(getFontWithAlignedNumbers(font: "Raleway", size: 20)))
                }.padding(.horizontal, 15)
            }
            
            ZStack {
                Color.white
                
                Button(action: {
                    withAnimation {
                        appData.sets.append(MathSet(name: currentSetStyle.name, color: currentSetStyle.color))
                    }
                }) {
                    Image(systemName: "arrowtriangle.up.circle.fill")
                        .font(.system(size: 25))
                        .foregroundColor(currentSetStyle.color)
                }.buttonStyle(PlainButtonStyle())
            }.aspectRatio(1.0, contentMode: .fit)
        }.disabled(appData.sets.count >= setStyles.count)
    }
}

struct CanvasMessageView: View {
    var text: String
    
    var nextPhase: CanvasPhases? = nil
    var delay: Double = 3.0
    var onAppear: () -> () = {}
    
    @Binding var currentPhase: CanvasPhases
    
    var animation: Namespace.ID
    
    @State var showingSpeech = false
    @State var paused = false
    
    var body: some View {
        VStack(alignment: .trailing) {
            if showingSpeech {
                speech
            }
            
            SethView(paused: $paused)
                .frame(width: 165)
                .animation(Animation.easeInOut(duration: 1.25))
                .matchedGeometryEffect(id: "Seth", in: animation)
        }.onAppear {
            onAppear()
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                showingSpeech = true
            }
        }
    }
    
    var speech: some View {
        SpeechView(text: text, completion: {
            paused = true
            DispatchQueue.main.asyncAfter(deadline: .now()+delay, execute: {
                if nextPhase != nil {
                    currentPhase = nextPhase!
                }
            })
        }, arrowPosition: .bottomTrailing, lineWidth: 10.0, innerPadding: 15)
            .foregroundColor(Color.playgroundTheme.black)
            .font(Font.custom("Raleway", size: 16).weight(.semibold))
            .frame(width: 215)
            .transition(AnyTransition.scale(scale: 0.5, anchor: .bottomTrailing).combined(with: .opacity))
    }
}

enum CanvasPhases {
    case welcome
    case tryit
    case send
    case great
}
