// This SwiftUI view presents the main and final screen of the playground experience

import SwiftUI

struct CanvasScreen: View {
    @State var scale: CGFloat = 1.0
    
    var body: some View {
        ZStack {
            Image(nsImage: NSImage(named: "Background Tile.png")!)
                .resizable(resizingMode: .tile)
                .opacity(0.2)
            
            VStack {
                Spacer()
                Capsule().fill(Color.black)
            }
        }.frame(width: playgroundSize.width*2, height: playgroundSize.height*2)
        .scaleEffect(scale)
        .gesture(MagnificationGesture().onChanged { value in
            scale = max(min((value+1)/pow(2, abs((value+1))/500+1), 2), 0.5)
        }.onEnded { value in
            withAnimation {
                scale = 1.0
            }
        })
    }
}
