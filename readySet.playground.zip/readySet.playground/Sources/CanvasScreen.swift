// This SwiftUI view presents the main and final screen of the playground experience

import SwiftUI

struct CanvasScreen: View {
    @EnvironmentObject var appData: DataModel
    
    var animation: Namespace.ID
    
    @State var scale: CGFloat = 1.0
    @State var text: String = ""
    
    @State var definingBy: Definitions = .enumeration
    
    var body: some View {
        ZStack {
            ZStack {
                Image(nsImage: NSImage(named: "Background Tile.png")!)
                    .resizable(resizingMode: .tile)
                    .opacity(0.1)
                    .frame(width: playgroundSize.width*2, height: playgroundSize.height*2)
                    .gesture(MagnificationGesture().onChanged { value in
                        let normalized = abs(value+1)
                        scale = max(min(normalized/pow(2, normalized/500+1), 2), 0.5)
                    }.onEnded { value in
                        withAnimation {
                            scale = 1.0
                        }
                    })
                
                Circle()
                    .stroke(Color.playgroundTheme.purple,lineWidth: 4)
                    .background(Circle().foregroundColor(Color.playgroundTheme.purple.opacity(0.45)))
                    .frame(width: 200, height: 200)
            }.scaleEffect(scale)
            
            ZStack {
                VStack(alignment: .trailing) {
                    Spacer()
                    SethView(paused: .constant(false))
                        .frame(width: 150)
                        .matchedGeometryEffect(id: "Seth", in: animation)
                    
                    VStack(spacing: 0) {
                        HStack(alignment: .bottom, spacing: 0) {
                            ForEach(appData.sets, id: \.color, content: { set in
                                SetBarView(mathSet: set)
                            })
                        }.overlay(LinearGradient(gradient: Gradient(colors: [Color.white.opacity(0.3), Color.white.opacity(0)]), startPoint: .top, endPoint: .center))
                        
                        HStack {
                            ZStack {
                                Color.white
                                
                                Menu {
                                    Text("Notation")
                                    Button(action: {
                                        definingBy = .enumeration
                                    }) {
                                        Text("Enumeration \(definingBy == .enumeration ? "􀆅" : "")")
                                    }
                                    Button(action: {
                                        definingBy = .builder
                                    }) {
                                        Text("Set-builder \(definingBy == .builder ? "􀆅" : "")")
                                    }
                                } label: {
                                    EmptyView()
                                        .frame(width: 40, height: 50)
                                }.menuStyle(style())
                                
                                Image(systemName: definingBy == .enumeration ? "number" : "rectangle.portrait.arrowtriangle.2.inward")
                                    .allowsHitTesting(false)
                                    .font(.system(size: 22, weight: .medium))
                            }.aspectRatio(1.0, contentMode: .fit)
                            
                            HStack {
                                Text("A = {").font(.system(size: 20, weight: .regular, design: .serif))
                                TextField("2, 3, 5...", text: $text)
                                    .font(Font(getFontWithAlignedNumbers(font: "Raleway", size: 20)))
                                    .textFieldStyle(PlainTextFieldStyle())
                            }
                        }.frame(height: 50)
                        .background(Color.playgroundTheme.white)
                    }.cornerRadius(15.0)
                    .shadow(color: Color.black.opacity(0.05), radius: 10, x: 5, y: 5)
                }.padding(30)
            }.frame(width: playgroundSize.width, height: playgroundSize.height)
        }
    }
}

struct SetBarView: View {
    var mathSet: MathSet
    
    var body: some View {
        mathSet.color
    }
}

struct style: MenuStyle {
    func makeBody(configuration: Configuration) -> some View {
        
    }
}
