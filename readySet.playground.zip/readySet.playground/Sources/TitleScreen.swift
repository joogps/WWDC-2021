// This SwiftUI view renders the title screen of this playground experience

import SwiftUI

struct TitleScreen: View {
    @EnvironmentObject var playgroundData: DataModel
    
    @State var animationState: TitleAnimationState = .splash
    
    @State var mouseLocation = CGPoint(x: playgroundSize.midX, y: playgroundSize.midY)
    var perspectiveAxis: (x: CGFloat, y: CGFloat, z: CGFloat) {
        let x = (mouseLocation.y-playgroundSize.midY)/2
        let y = (mouseLocation.x-playgroundSize.midX)/2
        
        return (x: -x, y: y, z: 0)
    }
    
    var body: some View {
        ZStack {
            if animationState >= .background {
                background
                logo
                button
            } else {
                splash
            }
        }.onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now()+2) {
                withAnimation {
                    animationState = .background
                }
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now()+3.5) {
                withAnimation {
                    animationState = .logo
                }
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now()+5) {
                withAnimation {
                    animationState = .grid
                }
            }
        }
    }
    
    var splash: some View {
        VStack {
            Spacer()
            Text("Swift Student Challenge '21")
                .font(Font(getFontWithAlignedNumbers(font: "Raleway Medium", size: 25)))
            Spacer()
            Text("made by @joogps. all rights reserved.")
                .font(.custom("Raleway", size: 18))
                .foregroundColor(Color(.systemGray))
        }.padding(40)
    }
    
    var background: some View {
        ZStack {
            IrregularGradient(colors: [Color.playgroundTheme.blue, Color.playgroundTheme.yellow, Color.playgroundTheme.green, Color.playgroundTheme.purple])
                .trackingMouse { location in
                    self.mouseLocation = location
                }
                .overlay(
                    RadialGradient(gradient: Gradient(colors: [Color.playgroundTheme.white, Color.playgroundTheme.white.opacity(0)]), center: .bottom, startRadius: animationState > .grid ? 1000 : 1, endRadius: animationState > .grid ? 2000 : 1)
                        .animation(Animation.spring(response: 0.9, dampingFraction: 0.9).delay(2))
                )
            
            if animationState >= .grid {
                SymbolGrid(animationState: $animationState)
                    .frame(width: playgroundSize.width, height: playgroundSize.height)
            }
            
            Color.playgroundTheme.white.opacity(0.4)
        }
    }
    
    var logo: some View {
        ZStack {
            if animationState >= .logo && animationState <= .grid {
                Image(nsImage: NSImage(named: "Logo.png")!)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 230)
                .transition(.offset(y: 230))
                .rotation3DEffect(
                    .init(degrees: 7),
                    axis: perspectiveAxis
                )
                .shadow(color: Color.black.opacity(0.05), radius: 10, x: 5, y: 5)
                .animation(.spring(response: 0.7, dampingFraction: 0.9))
            }
        }.mask(Rectangle().frame(width: 500, height: 230, alignment: .center))
    }
    
    var button: some View {
        VStack {
            Button("", action: {
                withAnimation(Animation.spring(response: 0.7, dampingFraction: 0.9).delay(0.25)) {
                    animationState = .exit
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now()+3, execute: {
                    withAnimation {
                        playgroundData.currentScreen = .intro
                    }
                })
            }).opacity(0)
            .disabled(!(animationState == .grid))
            .allowsHitTesting(false)
            .keyboardShortcut("r")
            
            Spacer()
            
            if animationState == .grid {
                Text("press ⌘R to begin")
                    .font(.custom("Raleway Semibold", size: 22))
                    .foregroundColor(.white)
                    .shadow(color: Color.black.opacity(0.1), radius: 10, x: 5, y: 5)
                    .transition(AnyTransition.offset(y: 25).combined(with: .opacity))
            }
        }.padding(80)
    }
}

enum TitleAnimationState: Int, Comparable {
    static func < (lhs: TitleAnimationState, rhs: TitleAnimationState) -> Bool {
        return lhs.rawValue < rhs.rawValue
    }
    
    case splash = 0
    case background = 1
    case logo = 2
    case grid = 3
    case exit = 4
}

// the view that renders the grid of symbols in the background

struct SymbolGrid: View {
    @State var symbols = [GridSymbol]()
    
    @Binding var animationState: TitleAnimationState
    
    let optionPool = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "Ø", "{", "}", "U"]
    let columns = Array(repeating: GridItem(.flexible()), count: 8)
    
    let indexes = Set(0...64-1)
        .subtracting(3*8+3-1...3*8+6-1)
        .subtracting(4*8+3-1...4*8+6-1)
        .subtracting(6*8+4-1...6*8+5-1)
    
    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        LazyVGrid(columns: columns, spacing: 18) {
            ForEach(symbols, id:\.id) { symbol in
                Text(symbol.text)
                    .transition(AnyTransition.offset([CGSize(width: 1, height: 0),
                                                        CGSize(width: 0, height: 1),
                                                        CGSize(width: -1, height: 0),
                                                        CGSize(width: 0, height: -1)].randomElement()!
                                                        .applying(.init(scaleX: 20, y: 20))).combined(with: .opacity))
                    .opacity(symbol.opacity)
                    .clipShape(Rectangle())
            }
        }.font(Font(getFontWithAlignedNumbers(font: "Raleway ExtraBold", size: 72)))
        .foregroundColor(.white)
        .onChange(of: animationState) { _ in
            if animationState > .grid {
                for n in 0...63 {
                    withAnimation(Animation.easeInOut(duration: 1).delay(Double.random(in: 0...1))) {
                        symbols[n] = GridSymbol(text: " ")
                    }
                }
            }
        }.onAppear {
            for _ in 1...64 {
                symbols.append(GridSymbol(text: " ", opacity: 1.0))
            }
            
            for n in indexes {
                withAnimation(Animation.easeInOut(duration: 1).delay(Double.random(in: 0...2))) {
                    setSymbol(for: n)
                }
            }
        }.onReceive(timer) { _ in
            if animationState < .exit {
                withAnimation(Animation.easeInOut(duration: 0.5)) {
                    setSymbol(for: indexes.randomElement()!)
                }
            }
        }
    }
    
    func setSymbol(for index: Int, delay: Double = 0) {
        let symbol = optionPool.randomElement()!
        let dontPanic = Double.random(in: 0...1)
        
        symbols[index] = GridSymbol(text: dontPanic < 0.01 ? "42" : symbol, opacity: Double.random(in: 0.1...0.5))
    }
}

struct GridSymbol {
    var id = UUID()
    var text: String
    var opacity: Double = 1.0
}
