import PlaygroundSupport
import SwiftUI

let playgroundSize = CGRect(x: 0, y: 0, width: 960, height: 700)

struct ContentView: View {
    @ObservedObject var playgroundData = DataModel()
    
    var body: some View {
        Group {
            switch playgroundData.currentScreen {
            case .title:
                TitleScreen()
                    .environmentObject(playgroundData)
            case .intro:
                IntroScreen()
                    .environmentObject(playgroundData)
            case.canvas:
                CanvasScreen()
                    .environmentObject(playgroundData)
            }
        }.frame(width: playgroundSize.width, height: playgroundSize.height)
        .clipShape(RoundedRectangle(cornerRadius: 25.0, style: .continuous))
    }
}

public func readySet() {
    let view = ContentView()
    PlaygroundPage.current.setLiveView(view)
}

