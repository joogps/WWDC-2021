/*:
# { readySet
 
 Welcome to readySet! This is a quick playground experience designed to teach people about set theory, one of the coolest branches in the study of mathematics. Join Seth in this magical journey and discover amazing things about math sets. **Are you ready to set?**
 
## Cheatsheet
### General
 - **Set theory:** the branch of mathematics that studies sets.
 - **Set:** a collection of non-repeatable objects.
 - **Enumeration:** a method of defining a set by enumerating its elements.
 - **Subset:** a set that derives from the elements of another set.
 - **Empty set:** a set with no elements. It's often represented by the symbol Ø.
 
 ### Diagrams
 - **Venn diagram:** one of ways to graphically represent math sets.
 - **Intersection:** the diagram formed by two overlapping sets A and B that share common elements. Its middle can be represented by **A ∩ B**.
 - **Containment:** the diagram of two contained sets A and B where all elements of one belong to the other. It can be defined by **A ⊂ B** or **B ⊂ A**, depending on which set is a subset of which.
 - **Three:** a diagram containing three sets A, B and C that all share a same subset of elements. Its center can be expressed by **A ∩ B ∩ C**.
 
 ___
 **Open-source code used in this playground:**
 - [IrregularGradient](https://github.com/joogps/IrregularGradient), built by me and made available via the MIT License;
 - TrackingAreaView, _proudly taken_ from [this article](https://swiftui-lab.com/a-powerful-combo/) from The SwiftUI Lab.
 ___
*/

readySet()
