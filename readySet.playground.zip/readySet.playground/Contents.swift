/*:
 # { readySet
 
 Welcome to readySet! This is a quick playground experience designed to teach people about set theory, one of the coolest branches in the study of mathematics. Join Seth in this magical journey and discover amazing things about math. **Are you ready to set?**
 
 ___
 **Open-source code used in this playground:**
 - [IrregularGradient](https://github.com/joogps/IrregularGradient), built by me and made available via the MIT License;
 ___
*/

readySet()
